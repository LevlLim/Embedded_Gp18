/*
 * obstacle_scan.c
 *
 * Subsystem 5 -- HC-SR04P scanning and obstacle profiling.
 * Statechart 5, Design Review V2 section 6.5.
 *
 * HARDWARE NOTE: HC-SR04P at 3.3 V.  TRIG is driven from GP6 at 3.3 V,
 * which the -P variant accepts, and ECHO returns 3.3 V so it goes
 * directly to GP7 with no divider.  Echo timing is done by the shared
 * IO_BANK0 dispatcher (drivers/gpio_irq.c), not by busy-waiting here --
 * a 30 ms busy-wait in a Medium-priority task would be a scheduling
 * problem all by itself.
 */

#include "subsystem5.h"
#include "../fault.h"
#include "../drivers/gpio_irq.h"
#include "../drivers/rp2040_regs.h"
#include "../subsystem2/subsystem2.h"
#include "../subsystem3/subsystem3.h"

EXPORT ID tid_obstacle = 0;
EXPORT ID mbf_obstacle = 0;

/* ---------------------------------------------------------------------
 * Private state
 * --------------------------------------------------------------------- */

static s5_obstacle_phase_t phase = OB_COARSE_SCAN;
static msg_obstacle_t      profile;
static bool                b_have_profile = false;
static uint8_t             retries = 0u;
static int8_t              servo_angle = 0;
static uint32_t            last_echo_seq = 0u;

/* Fine-scan accumulation. */
static uint8_t  min_distance_cm = 255u;
static int8_t   min_bearing_deg = 0;
static uint8_t  hit_count       = 0u;
static int8_t   first_hit_deg   = 0;
static int8_t   last_hit_deg    = 0;

/* ---------------------------------------------------------------------
 * Private functions
 * --------------------------------------------------------------------- */

/*
 * Point the servo.  Angle is degrees from straight ahead, positive right.
 */
static void servo_point(int8_t angle_deg)
{
    uint32_t pulse_us;

    if (angle_deg > 60)       { angle_deg = 60; }
    else if (angle_deg < -60) { angle_deg = -60; }
    else                      { /* in range */ }

    pulse_us = (uint32_t)((int32_t)S5_SERVO_CENTRE_US
                        + ((int32_t)angle_deg * (int32_t)S5_SERVO_US_PER_DEG));

    /* 50 Hz frame = 20000 us.  pwm_set_wrap was configured for 20000 in
       subsystem5_init, so the compare value is directly in microseconds. */
    (void)pwm_set_cc(PIN_SERVO_SCAN, pulse_us);

    servo_angle = angle_deg;
}

/*
 * Fire one ranging pulse and return the distance, or 0 if no echo.
 * Non-blocking with respect to the echo: the dispatcher times the pulse
 * and this function reads the result on a later call.
 */
static uint16_t ping_and_read(void)
{
    gpio_irq_echo_t echo;
    uint16_t        distance_cm = 0u;

    /* 10 us trigger pulse. */
    (void)gpio_set_val(PIN_US_TRIG, 1u);
    (void)tk_dly_tsk(1);            /* 1 ms; far longer than 10 us but the
                                       module only needs a minimum width */
    (void)gpio_set_val(PIN_US_TRIG, 0u);

    /* Give the echo time to come back before looking. */
    (void)tk_dly_tsk(40);

    if (gpio_irq_read_echo(&echo))
    {
        if (echo.seq != last_echo_seq)
        {
            last_echo_seq = echo.seq;

            if (echo.width_us < S5_ECHO_TIMEOUT_US)
            {
                distance_cm = s5_echo_us_to_cm(echo.width_us);
            }
        }
    }

    return (distance_cm);
}

/*
 * Publish the completed profile to the Controller.
 */
static void publish_profile(void)
{
    uint8_t buf[MSG_LEN_OBSTACLE];
    uint8_t len;

    len = msg_pack_obstacle(&profile, buf, sizeof(buf));

    if (0u != len)
    {
        (void)tk_snd_mbf(mbf_obstacle, buf, (INT)len, TMO_POL);
        s5_post_event(S5_EVT_OBSTACLE);
        b_have_profile = true;
    }
}

/* ---------------------------------------------------------------------
 * Public pure helpers (tested on the host)
 * --------------------------------------------------------------------- */

EXPORT uint16_t s5_echo_us_to_cm(uint32_t width_us)
{
    /*
     * Sound travels about 343 m/s = 34300 cm/s = 0.0343 cm/us.  The pulse
     * covers the distance twice, so cm = width_us * 0.0343 / 2, which is
     * width_us / 58 in integer maths.
     */
    return ((uint16_t)(width_us / 58u));
}

EXPORT msg_side_t s5_choose_side(uint8_t clear_left_cm, uint8_t clear_right_cm,
                                 uint8_t needed_cm)
{
    msg_side_t side;

    if ((clear_left_cm < needed_cm) && (clear_right_cm < needed_cm))
    {
        /* Neither side fits the robot plus margin. */
        side = MSG_SIDE_NONE;
    }
    else if (clear_left_cm >= clear_right_cm)
    {
        side = MSG_SIDE_LEFT;
    }
    else
    {
        side = MSG_SIDE_RIGHT;
    }

    return (side);
}

/*
 * The obstacle phase machine.
 *
 * Split out of obstacle_task() to stay inside the 100-line limit of
 * Barr-C 6.2a.  Each phase interprets the SAME ultrasonic reading
 * differently, which is why this is a statechart and not if/else.
 */
static void step_phase_machine(uint16_t distance_cm, int8_t *p_sweep_dir)
{
    msg_motion_cmd_t cmd;
    uint8_t          needed;

    switch (phase)
    {
        case OB_COARSE_SCAN:
            /*
             * Sweep a BOUNDED forward arc while driving, not a full
             * 180 degrees.  Risk R6: the servo can be facing away
             * when an obstacle appears ahead, so the arc is kept
             * narrow at speed and D_detect is set from the worst-case
             * sweep phase rather than the best.
             */
            servo_point((int8_t)(servo_angle
                               + ((*p_sweep_dir) * S5_FINE_STEP_DEG)));

            if (servo_angle >= S5_COARSE_ARC_DEG)       { *p_sweep_dir = -1; }
            else if (servo_angle <= -S5_COARSE_ARC_DEG) { *p_sweep_dir = 1; }
            else                                        { /* sweeping */ }

            if ((0u != distance_cm) && (distance_cm <= PROV_D_DETECT_CM))
            {
                phase = OB_STOP;
            }
            break;

        case OB_STOP:
            /* Brake so that profiling happens from a fixed position:
               a scan taken while moving smears the bearings. */
            cmd.type = MSG_CMD_STOP;
            cmd.arg  = 0u;
            cmd.seq  = 0u;
            (void)s2_send_command(&cmd);

            min_distance_cm = 255u;
            hit_count       = 0u;
            servo_point(-S5_COARSE_ARC_DEG);
            (void)tk_dly_tsk(S5_SETTLE_MS);
            phase = OB_FINE_SCAN;
            break;

        case OB_FINE_SCAN:
            if ((0u != distance_cm) && (distance_cm <= PROV_D_DETECT_CM))
            {
                if (0u == hit_count)
                {
                    first_hit_deg = servo_angle;
                }
                last_hit_deg = servo_angle;
                hit_count    = (uint8_t)(hit_count + 1u);

                if (distance_cm < min_distance_cm)
                {
                    min_distance_cm = (uint8_t)distance_cm;
                    min_bearing_deg = servo_angle;
                }
            }

            servo_point((int8_t)(servo_angle + S5_FINE_STEP_DEG));
            (void)tk_dly_tsk(S5_SETTLE_MS);

            if (servo_angle >= S5_COARSE_ARC_DEG)
            {
                if (0u == hit_count)
                {
                    /* Nothing confirmed: it was a false alarm. */
                    phase = OB_COARSE_SCAN;
                }
                else
                {
                    phase = OB_PROFILE;
                }
            }
            break;

        case OB_PROFILE:
        {
            int32_t span_deg = (int32_t)last_hit_deg
                             - (int32_t)first_hit_deg;
            bool    b_sat    = false;

            /*
             * Width from the angular span at the measured distance.
             * The ~15 degree beam makes this an over-estimate, which
             * is assumption A6 and still unvalidated.  Over-estimating
             * is the safe direction: a too-wide bypass is clumsy, a
             * too-narrow one is a collision.
             */
            profile.distance_cm = min_distance_cm;
            profile.bearing_deg = min_bearing_deg;
            profile.width_cm    = (uint8_t)msg_sat_u16(
                    (uint32_t)((span_deg * (int32_t)min_distance_cm) / 57),
                    (uint16_t)MSG_MAX_OBST_WIDTH, &b_sat);

            profile.clear_left_cm  = (uint8_t)msg_sat_u16(
                    (uint32_t)(S5_COARSE_ARC_DEG + first_hit_deg),
                    (uint16_t)MSG_MAX_OBST_CLEAR, &b_sat);
            profile.clear_right_cm = (uint8_t)msg_sat_u16(
                    (uint32_t)(S5_COARSE_ARC_DEG - last_hit_deg),
                    (uint16_t)MSG_MAX_OBST_CLEAR, &b_sat);

            profile.b_saturated = b_sat;
            phase = OB_PLAN_BYPASS;
            break;
        }

        case OB_PLAN_BYPASS:
            needed = (uint8_t)(S5_ROBOT_WIDTH_CM + S5_CLEARANCE_MARGIN_CM);
            profile.side = s5_choose_side(profile.clear_left_cm,
                                          profile.clear_right_cm,
                                          needed);

            publish_profile();

            if (MSG_SIDE_NONE == profile.side)
            {
                phase = OB_REVERSE_RETRY;
            }
            else
            {
                phase = OB_BYPASS;
            }
            break;

        case OB_BYPASS:
            /* The Controller drives the bypass legs; this task keeps
               watching distance and holds the servo forward so it is
               looking where the car is going. */
            servo_point(0);
            phase = OB_SEARCH_LINE;
            break;

        case OB_SEARCH_LINE:
            if (MSG_LINE_TRACK == s3_get_line_state())
            {
                s5_post_event(S5_EVT_LINE_FOUND);
                retries = 0u;
                phase   = OB_COARSE_SCAN;
            }
            break;

        case OB_REVERSE_RETRY:
            if (retries < S5_MAX_RETRIES)
            {
                retries  = (uint8_t)(retries + 1u);
                cmd.type = MSG_CMD_FORWARD;
                cmd.arg  = 100u;        /* back off 100 mm */
                cmd.seq  = (uint8_t)(retries & 0x07u);
                (void)s2_send_command(&cmd);
                phase = OB_COARSE_SCAN;
            }
            else
            {
                phase = OB_ABORT;
            }
            break;

        case OB_ABORT:
            cmd.type = MSG_CMD_STOP;
            cmd.arg  = 0u;
            cmd.seq  = 0u;
            (void)s2_send_command(&cmd);
            break;

        default:
            phase = OB_COARSE_SCAN;
            break;
    }
}

/* ---------------------------------------------------------------------
 * The task
 * --------------------------------------------------------------------- */

EXPORT void obstacle_task(INT stacd, void *exinf)
{
    uint16_t distance_cm;
    int8_t   sweep_dir = 1;

    (void)stacd;
    (void)exinf;

    servo_point(0);

    for (;;)
    {
        distance_cm = ping_and_read();

        /*
         * D_stop check, in EVERY phase.  A reading inside the hard stop
         * distance sets the fault bit directly, so Motion Control brakes
         * without waiting for the Controller to be scheduled (NFR2).
         */
        if ((0u != distance_cm) && (distance_cm <= PROV_D_STOP_CM))
        {
            fault_set(FAULT_OBSTACLE_STOP);
        }

        if (0u == distance_cm)
        {
            /* No echo.  A single miss is normal at range; persistent
               misses mean the sensor is not working, which is a DEGRADE
               fault, not a stop. */
            if (hit_count > 200u)
            {
                fault_set(FAULT_NO_ECHO);
            }
        }

        step_phase_machine(distance_cm, &sweep_dir);

        (void)tk_dly_tsk(PERIOD_OBSTACLE_MS);
    }
}

EXPORT bool s5_get_obstacle(msg_obstacle_t *p_out)
{
    bool b_ok = false;

    if ((NULL != p_out) && b_have_profile)
    {
        *p_out = profile;
        b_ok   = true;
    }

    return (b_ok);
}
