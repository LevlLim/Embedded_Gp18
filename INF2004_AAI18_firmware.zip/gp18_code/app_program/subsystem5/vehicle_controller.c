/*
 * vehicle_controller.c
 *
 * Subsystem 5 -- the mission state machine.
 * System-level statechart, Design Review V2 section 5.
 *
 * THE SINGLE DECISION POINT.  Only this task issues move and turn
 * commands, and only this task clears fault bits.  Every other subsystem
 * reports; none of them drives.
 *
 * The emergency-stop path deliberately BYPASSES this task: fault setters
 * write the bit and Motion Control brakes on it directly, so braking does
 * not inherit this task's Medium-priority scheduling delay.  This task
 * then catches up and decides what the mission does next.
 */

#include "subsystem5.h"
#include "../fault.h"
#include "../subsystem2/subsystem2.h"
#include "../subsystem3/subsystem3.h"
#include "../subsystem4/subsystem4.h"

EXPORT ID tid_controller = 0;
EXPORT ID flg_events     = 0;

/* ---------------------------------------------------------------------
 * Private state
 * --------------------------------------------------------------------- */

static s5_parent_t parent   = S5_PARENT_INIT;
static s5_sub_t    substate = S5_SUB_LINE_FOLLOW;
static uint8_t     cmd_seq  = 0u;
static uint32_t    search_start_ms = 0u;

/* ---------------------------------------------------------------------
 * Private functions
 * --------------------------------------------------------------------- */

static void send(msg_cmd_type_t type, uint16_t arg)
{
    msg_motion_cmd_t cmd;

    cmd.type = type;
    cmd.arg  = arg;
    cmd.seq  = (uint8_t)(cmd_seq & 0x07u);
    cmd_seq  = (uint8_t)(cmd_seq + 1u);

    (void)s2_send_command(&cmd);
}

static void enter_running(void)
{
    parent   = S5_PARENT_RUNNING;
    substate = S5_SUB_LINE_FOLLOW;

    s3_set_active(true);
    s4_set_active(true);
    send(MSG_CMD_LINE_PID, 0u);
}

static void enter_stopped(void)
{
    parent   = S5_PARENT_STOPPED;
    s3_set_active(false);
    s4_set_active(false);
    send(MSG_CMD_STOP, 0u);
}

static void enter_fault(void)
{
    parent = S5_PARENT_FAULT;
    s3_set_active(false);
    s4_set_active(false);
    send(MSG_CMD_STOP, 0u);
}

/*
 * Act on a decoded barcode command.
 */
static void handle_barcode(void)
{
    uint8_t       buf[MSG_LEN_BARCODE];
    msg_barcode_t bc;
    INT           received;

    received = tk_rcv_mbf(mbf_barcode, buf, TMO_POL);

    if (received < (INT)MSG_LEN_BARCODE)
    {
        return;
    }
    if (!msg_unpack_barcode(buf, MSG_LEN_BARCODE, &bc))
    {
        return;
    }

    /*
     * A low-confidence decode is ignored rather than acted on.  Executing
     * a wrong turn takes the car off the track; ignoring a command just
     * continues straight, and the symbol can be read again next lap.
     */
    if (bc.confidence < 4u)
    {
        tm_printf((UB*)"[S5] barcode ignored, confidence %d\n",
                  (INT)bc.confidence);
        return;
    }

    substate = S5_SUB_BARCODE_ACTION;

    switch (bc.cmd)
    {
        case MSG_BC_STRAIGHT: send(MSG_CMD_FORWARD, 200u); break;
        case MSG_BC_LEFT:     send(MSG_CMD_TURN_L,   90u); break;
        case MSG_BC_RIGHT:    send(MSG_CMD_TURN_R,   90u); break;
        case MSG_BC_U_TURN:   send(MSG_CMD_U_TURN,  180u); break;
        default:
            substate = S5_SUB_LINE_FOLLOW;
            break;
    }
}

/*
 * React to the current fault word.  E-STOP bits send the mission to
 * FAULT; DEGRADE bits only reduce what the car attempts.
 */
static void handle_faults(uint16_t bits)
{
    if (0u != (bits & FAULT_MASK_ESTOP))
    {
        if (S5_PARENT_FAULT != parent)
        {
            tm_printf((UB*)"[S5] E-STOP: mask 0x%03x\n", (INT)bits);
            enter_fault();
        }
    }
    else if (0u != (bits & FAULT_MASK_DEGRADE))
    {
        /*
         * Keep running, but reduced.  IMU_FAULT means collision detection
         * is gone, so the car slows; NO_ECHO means obstacle detection is
         * degraded, same response.  The run is allowed to finish rather
         * than being abandoned mid-track, and telemetry carries the bit
         * so the operator knows why.
         */
        if (0u != (bits & FAULT_IMU))
        {
            /* FR4/FR5 reporting for this run is already marked invalid
               by subsystem 4; nothing further to do here. */
        }
    }
    else
    {
        /* No fault. */
    }
}

/* ---------------------------------------------------------------------
 * The task
 * --------------------------------------------------------------------- */

EXPORT void controller_task(INT stacd, void *exinf)
{
    UINT     events;
    uint16_t faults;
    ER       er;

    (void)stacd;
    (void)exinf;

    /* ---- INIT: self-test, then READY or FAULT ---- */
    parent = S5_PARENT_INIT;

    (void)gpio_set_pin(PIN_BTN_START, GPIO_MODE_IN);
    (void)gpio_set_pin(PIN_BTN_STOP,  GPIO_MODE_IN);

    if (s3_calibrate() < E_OK)
    {
        tm_printf((UB*)"[S5] self-test failed: line calibration\n");
        parent = S5_PARENT_FAULT;
    }
    else
    {
        parent = S5_PARENT_READY;
        tm_printf((UB*)"[S5] READY -- press START or publish a command\n");
    }

    for (;;)
    {
        /*
         * Wait for an event, with a timeout so the loop also polls the
         * buttons and the fault word.  TWF_ORW with clear: this task is
         * the single consumer of flg_events, so consuming is correct here
         * -- unlike flg_fault, which has several waiters.
         */
        events = 0u;
        er = tk_wai_flg(flg_events, S5_EVT_ALL, TWF_ORW | TWF_CLR,
                        &events, 50);

        if (er < E_OK)
        {
            events = 0u;        /* timeout: fall through and poll */
        }

        faults = fault_get();
        handle_faults(faults);

        /* ---- buttons ---- */
        if (0u == gpio_get_val(PIN_BTN_STOP))
        {
            fault_set(FAULT_REMOTE_STOP);
        }
        if ((0u == gpio_get_val(PIN_BTN_START))
            && (S5_PARENT_READY == parent))
        {
            events |= S5_EVT_REMOTE_START;
        }

        /* ---- events ---- */
        if (0u != (events & S5_EVT_REMOTE_START))
        {
            if ((S5_PARENT_READY == parent) || (S5_PARENT_STOPPED == parent))
            {
                s4_reset_run();
                fault_clear(FAULT_MASK_ALL);
                enter_running();
                tm_printf((UB*)"[S5] RUNNING\n");
            }
        }

        if (0u != (events & S5_EVT_REMOTE_STOP))
        {
            enter_stopped();
        }

        if (0u != (events & S5_EVT_RESET))
        {
            /* Sole fault-clearing authority.  Clearing happens here and
               nowhere else, which is what stops two tasks racing to clear
               a bit the other still needs. */
            fault_clear(FAULT_MASK_ALL);
            s4_reset_run();
            parent = S5_PARENT_READY;
            tm_printf((UB*)"[S5] RESET -> READY\n");
        }

        if (S5_PARENT_RUNNING != parent)
        {
            continue;
        }

        if (0u != (events & S5_EVT_BARCODE))
        {
            handle_barcode();
        }

        if (0u != (events & S5_EVT_MOVE_DONE))
        {
            /* A manoeuvre finished: return to line following. */
            substate = S5_SUB_LINE_FOLLOW;
            send(MSG_CMD_LINE_PID, 0u);
        }

        if (0u != (events & S5_EVT_OBSTACLE))
        {
            /*
             * Reachable from LINE_FOLLOW, BARCODE_ACTION and LINE_SEARCH.
             * The Week 6 design only handled it from LINE_FOLLOW, which
             * meant an obstacle appearing mid-turn was ignored.
             */
            substate = S5_SUB_OBSTACLE_AVOID;
        }

        if (0u != (events & S5_EVT_LINE_LOST))
        {
            if (S5_SUB_LINE_SEARCH != substate)
            {
                substate        = S5_SUB_LINE_SEARCH;
                search_start_ms = app_now_ms();
                /* Sweep to reacquire: a slow arc rather than a stop. */
                send(MSG_CMD_TURN_L, 20u);
            }
        }

        if (0u != (events & S5_EVT_LINE_FOUND))
        {
            substate = S5_SUB_LINE_FOLLOW;
            send(MSG_CMD_LINE_PID, 0u);
        }

        /* ---- line search timeout ---- */
        if (S5_SUB_LINE_SEARCH == substate)
        {
            if ((app_now_ms() - search_start_ms) > S5_SEARCH_TIMEOUT_MS)
            {
                /* Unrecoverable line loss: this is an E-STOP condition
                   per the Fault Table, so set the bit and let Motion
                   Control brake. */
                fault_set(FAULT_LINE_LOST_HARD);
            }
            else if (MSG_LINE_TRACK == s3_get_line_state())
            {
                substate = S5_SUB_LINE_FOLLOW;
                send(MSG_CMD_LINE_PID, 0u);
            }
            else
            {
                /* Still searching. */
            }
        }
    }
}

/* ---------------------------------------------------------------------
 * Public
 * --------------------------------------------------------------------- */

EXPORT void s5_post_event(uint32_t event_bits)
{
    if (flg_events > 0)
    {
        (void)tk_set_flg(flg_events, (UINT)event_bits);
    }
}

EXPORT uint8_t s5_get_encoded_state(void)
{
    uint8_t sub = 0u;

    if (S5_PARENT_RUNNING == parent)
    {
        sub = (uint8_t)substate;
    }

    return (msg_encode_veh_state((uint8_t)parent, sub));
}
