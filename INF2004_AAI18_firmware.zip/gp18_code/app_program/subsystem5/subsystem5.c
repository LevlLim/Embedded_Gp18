/*
 * subsystem5.c
 *
 * Subsystem 5 -- obstacle and Vehicle Controller: creates the shared
 * event flag and the obstacle message buffer, configures the servo and
 * trigger pins, and starts both tasks.
 */

#include "subsystem5.h"
#include "../fault.h"

#define S5_OBSTACLE_QUEUE_DEPTH (2)
#define SERVO_FRAME_US          (20000u)   /* 50 Hz */

EXPORT ER subsystem5_init(void)
{
    T_CFLG cflg = {0};
    T_CMBF cmbf = {0};
    ER     er;

    /* The shared fault bitmask belongs to this subsystem (Fault Table). */
    er = fault_init();
    if (er < E_OK)
    {
        return (er);
    }

    /* Event flag: many producers, ONE consumer (the Controller). */
    cflg.flgatr  = TA_TFIFO | TA_WMUL;
    cflg.iflgptn = 0u;
    flg_events   = tk_cre_flg(&cflg);
    if (flg_events < E_OK)
    {
        return ((ER)flg_events);
    }

    cmbf.mbfatr  = TA_TFIFO;
    cmbf.bufsz   = (INT)(MSG_LEN_OBSTACLE * S5_OBSTACLE_QUEUE_DEPTH);
    cmbf.maxmsz  = (INT)MSG_LEN_OBSTACLE;
    mbf_obstacle = tk_cre_mbf(&cmbf);
    if (mbf_obstacle < E_OK)
    {
        return ((ER)mbf_obstacle);
    }

    /* Ultrasonic trigger is a plain output; ECHO is configured by the
       shared IO_BANK0 dispatcher in subsystem 2's init. */
    (void)gpio_set_pin(PIN_US_TRIG, GPIO_MODE_OUT);
    (void)gpio_set_val(PIN_US_TRIG, 0u);

    /*
     * Servo on PWM slice 6, deliberately a different slice from the
     * motors (4 and 5) so that 50 Hz and the motor frequency can coexist.
     * Wrap set to 20000 so the compare value is directly in microseconds.
     */
    (void)pwm_set_pin(PIN_SERVO_SCAN);
    (void)pwm_set_wrap(PIN_SERVO_SCAN, SERVO_FRAME_US);
    (void)pwm_set_cc(PIN_SERVO_SCAN, S5_SERVO_CENTRE_US);
    (void)pwm_set_enabled(PIN_SERVO_SCAN, TRUE);

    return (E_OK);
}

EXPORT ER subsystem5_start(void)
{
    tid_controller = app_start_task(controller_task, PRI_VEHICLE_CTRL,
                                    TP_PRC1, "controller_task");
    if (tid_controller < E_OK)
    {
        return ((ER)tid_controller);
    }

    tid_obstacle = app_start_task(obstacle_task, PRI_OBSTACLE_SCAN,
                                  TP_PRC1, "obstacle_task");

    return ((tid_obstacle < E_OK) ? (ER)tid_obstacle : E_OK);
}
