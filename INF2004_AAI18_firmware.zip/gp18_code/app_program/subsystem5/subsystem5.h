/*
 * subsystem5.h
 *
 * Subsystem 5 -- obstacle avoidance and the Vehicle Controller.
 * Buddy 5 (Jun Hong), 2501666.
 *
 * Implements the system-level statechart (Design Review V2 section 5) and
 * Statechart 5 (section 6.5).
 *
 * This subsystem holds two responsibilities that must stay together: it
 * owns the ultrasonic sensor, and it is the SOLE fault-clearing authority
 * and the SOLE source of motion commands.  Concentrating those here is
 * what gives the robot a single decision point.
 *
 * SENSOR: HC-SR04P, specified for a 3.0-5.5 V supply, run at 3.3 V with
 * ECHO wired directly to GP7 and no divider fitted.  The earlier plan to
 * move a plain HC-SR04 to 5 V was superseded: that would have presented
 * ~5 V to a pin that is not 5 V tolerant.
 */

#ifndef SUBSYSTEM5_H
#define SUBSYSTEM5_H

#include "../app.h"
#include "../msg_defs.h"
#include <stdint.h>
#include <stdbool.h>

/* ---------------------------------------------------------------------
 * Event flags raised by the other subsystems.  The Vehicle Controller is
 * the single consumer.
 * --------------------------------------------------------------------- */
#define S5_EVT_LINE_LOST        (0x0001u)
#define S5_EVT_BARCODE          (0x0002u)
#define S5_EVT_HUMP             (0x0004u)
#define S5_EVT_OBSTACLE         (0x0008u)
#define S5_EVT_MOVE_DONE        (0x0010u)
#define S5_EVT_REMOTE_START     (0x0020u)
#define S5_EVT_REMOTE_STOP      (0x0040u)
#define S5_EVT_RESET            (0x0080u)
#define S5_EVT_LINE_FOUND       (0x0100u)
#define S5_EVT_ALL              (0x01FFu)

/* System-level states.  Packed as 3-bit parent + 2-bit substate. */
typedef enum
{
    S5_PARENT_INIT    = 0,
    S5_PARENT_READY   = 1,
    S5_PARENT_RUNNING = 2,
    S5_PARENT_STOPPED = 3,
    S5_PARENT_FAULT   = 4
} s5_parent_t;

typedef enum
{
    S5_SUB_LINE_FOLLOW    = 0,
    S5_SUB_BARCODE_ACTION = 1,
    S5_SUB_OBSTACLE_AVOID = 2,
    S5_SUB_LINE_SEARCH    = 3
} s5_sub_t;

/* Statechart 5 phases. */
typedef enum
{
    OB_COARSE_SCAN   = 0,
    OB_STOP          = 1,
    OB_FINE_SCAN     = 2,
    OB_PROFILE       = 3,
    OB_PLAN_BYPASS   = 4,
    OB_BYPASS        = 5,
    OB_SEARCH_LINE   = 6,
    OB_REVERSE_RETRY = 7,
    OB_ABORT         = 8
} s5_obstacle_phase_t;

/* ---------------------------------------------------------------------
 * Servo and scanning geometry.  PROVISIONAL.
 * --------------------------------------------------------------------- */
#define S5_SERVO_CENTRE_US      (1500u)
#define S5_SERVO_US_PER_DEG     (11u)   /* ~1000 us over 90 degrees      */
#define S5_SETTLE_MS            (200u)  /* A6: 150-300 ms                */
#define S5_COARSE_ARC_DEG       (30)    /* bounded forward arc, risk R6  */
#define S5_FINE_STEP_DEG        (5)
#define S5_MAX_RETRIES          (2u)
#define S5_ECHO_TIMEOUT_US      (30000u)
#define S5_ROBOT_WIDTH_CM       (18u)
#define S5_CLEARANCE_MARGIN_CM  (5u)
#define S5_SEARCH_TIMEOUT_MS    (5000u) /* FR8: reacquire within 5 s     */

/* Post an event to the Vehicle Controller.  Safe from any task. */
void s5_post_event(uint32_t event_bits);

/* Current mission state, already encoded for telemetry. */
uint8_t s5_get_encoded_state(void);

/* Latest obstacle profile, for telemetry. */
bool s5_get_obstacle(msg_obstacle_t *p_out);

/* Convert an echo pulse width to centimetres.  Pure function, exposed for
   the host test.  Speed of sound ~343 m/s, there and back. */
uint16_t s5_echo_us_to_cm(uint32_t width_us);

/* Decide a bypass side from left/right clearance.  Pure function. */
msg_side_t s5_choose_side(uint8_t clear_left_cm, uint8_t clear_right_cm,
                          uint8_t needed_cm);

IMPORT ID mbf_obstacle;
IMPORT ID flg_events;

IMPORT ID   tid_controller;
IMPORT ID   tid_obstacle;
IMPORT void controller_task(INT stacd, void *exinf);
IMPORT void obstacle_task(INT stacd, void *exinf);

#endif /* SUBSYSTEM5_H */
