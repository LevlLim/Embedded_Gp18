/*
 * app.h
 *
 * Group AAI18 -- definitions shared by the whole team.
 * Changed only by team agreement.
 *
 * Anything that belongs to ONE subsystem goes in that subsystem's own
 * header instead (app_program/subsystemN/subsystemN.h).
 *
 * Subsystem map (Design Review V2 section 12.3):
 *   subsystem1/  Buddy 1  Telemetry / Comms      WiFi, MQTT, remote cmds
 *   subsystem2/  Buddy 2  Motion Control         motors, encoders, PID
 *   subsystem3/  Buddy 3  Line + Barcode         ADC sampler, IR, decode
 *   subsystem4/  Buddy 4  IMU / Terrain          hump, tilt, collision
 *   subsystem5/  Buddy 5  Obstacle + Controller  ultrasonic, mission state
 */

#ifndef APP_H
#define APP_H

#include <tk/tkernel.h>     /* micro T-Kernel API (tk_xxx_yyy)        */
#include <tm/tmonitor.h>    /* T-Monitor API: tm_printf()             */
#include <bsp/libbsp.h>     /* Board helpers: gpio_set_pin/val, pwm_  */

/* ---------------------------------------------------------------------
 *  PIN MAP -- Design Review V2 section 2.  One owner per pin.
 *  Free pins are GP0..GP22 and GP26..GP28.  GP0/GP1 are taken by UART0
 *  when built with CRASH_REPORT=1.  Never use GP23/24/25/29 (Pico W radio).
 * --------------------------------------------------------------------- */
#define PIN_ENC_L_A         (2u)    /* S2  left encoder phase A  (IRQ)   */
#define PIN_ENC_L_B         (3u)    /* S2  left encoder phase B          */
#define PIN_ENC_R_A         (4u)    /* S2  right encoder phase A (IRQ)   */
#define PIN_ENC_R_B         (5u)    /* S2  right encoder phase B         */
#define PIN_US_TRIG         (6u)    /* S5  HC-SR04P trigger              */
#define PIN_US_ECHO         (7u)    /* S5  HC-SR04P echo         (IRQ)   */
#define PIN_MOTOR_L_A       (8u)    /* S2  PWM slice 4 channel A         */
#define PIN_MOTOR_L_B       (9u)    /* S2  PWM slice 4 channel B         */
#define PIN_MOTOR_R_A       (10u)   /* S2  PWM slice 5 channel A         */
#define PIN_MOTOR_R_B       (11u)   /* S2  PWM slice 5 channel B         */
#define PIN_SERVO_SCAN      (12u)   /* S5  PWM slice 6, 50 Hz            */
#define PIN_IMU_SDA         (16u)   /* S4  I2C0 SDA                      */
#define PIN_IMU_SCL         (17u)   /* S4  I2C0 SCL                      */
#define PIN_STATUS_LED      (18u)   /* S5  WS2812 status LED             */
#define PIN_BTN_START       (20u)   /* S5  onboard start button          */
#define PIN_BTN_STOP        (21u)   /* S5  onboard stop button           */
#define PIN_BUZZER          (22u)   /* S5  PWM slice 3                   */
#define PIN_IR_LINE_L       (26u)   /* S3  ADC0  -- owned by adc_sampler */
#define PIN_IR_LINE_C       (27u)   /* S3  ADC1  -- owned by adc_sampler */
#define PIN_IR_BARCODE      (28u)   /* S3  ADC2  -- owned by adc_sampler */

/* ---------------------------------------------------------------------
 *  TASK PRIORITIES -- Design Review V2 section 3.
 *  1 is the highest.  The kernel's USB console (3) and WiFi (4) tasks sit
 *  above every application task, so application bands start at 5.
 *
 *  Priority follows timing criticality: shorter period and tighter
 *  deadline means higher priority.
 * --------------------------------------------------------------------- */
#define PRI_MOTION_CONTROL  (5)     /* Highest: 10 ms PID + e-stop brake */
#define PRI_LINE_SENSOR     (7)     /* High:    5 ms                     */
#define PRI_BARCODE         (8)     /* High:    1 ms scan                */
#define PRI_IMU_TERRAIN     (9)     /* High:    10 ms, 4 ms WCET         */
#define PRI_VEHICLE_CTRL    (12)    /* Medium:  event driven             */
#define PRI_OBSTACLE_SCAN   (13)    /* Medium:  60 ms (sensor rearm)     */
#define PRI_TELEMETRY       (20)    /* Low:     never delays driving     */

#define TASK_STACK_SIZE     (2048)  /* bytes; tm_printf needs ~1 KB      */

/* ---------------------------------------------------------------------
 *  TIMING -- periods in milliseconds.
 * --------------------------------------------------------------------- */
#define PERIOD_MOTION_MS    (10)
#define PERIOD_LINE_MS      (5)
#define PERIOD_BARCODE_MS   (1)
#define PERIOD_IMU_MS       (10)
#define PERIOD_OBSTACLE_MS  (60)    /* HC-SR04P minimum rearm interval   */
#define PERIOD_TELEMETRY_MS (200)   /* 5 Hz, satisfies FR9               */

/* ---------------------------------------------------------------------
 *  PROVISIONAL CONSTANTS.
 *  Every value here is an engineering estimate, not a measurement.  Each
 *  must be replaced from bench data before Week 10 -- see Design Review V2
 *  section 14, ordered actions 3 and 5.  They are gathered in one place so
 *  that it is obvious what has not yet been measured.
 * --------------------------------------------------------------------- */
#define PROV_D_DETECT_CM    (30u)   /* FR6  obstacle detection distance  */
#define PROV_D_STOP_CM      (20u)   /* NFR2 hard stop distance           */
#define PROV_CRUISE_PCT     (55u)   /* nominal cruising speed, % duty    */
#define PROV_DEGRADE_PCT    (30u)   /* speed cap when a DEGRADE fault is */
                                    /* active (e.g. IMU_FAULT)           */

/* ---------------------------------------------------------------------
 *  Create and start a task.  prc = TP_PRC1 (core 0), TP_PRC2 (core 1), or
 *  0 for "any core".  Defined in app_main.c.
 * --------------------------------------------------------------------- */
IMPORT ID app_start_task(FP entry, PRI pri, UW prc, const char *name);

/* Milliseconds since boot, from the kernel tick.  Used for the staleness
   timestamps that Motion Control checks on line_error. */
IMPORT uint32_t app_now_ms(void);

/* ---------------------------------------------------------------------
 *  Every subsystem provides these.  usermain() calls ALL the _init()
 *  functions first and only then ALL the _start() functions, so every
 *  kernel object exists before any task can use it.
 * --------------------------------------------------------------------- */
IMPORT ER subsystem1_init(void);
IMPORT ER subsystem2_init(void);
IMPORT ER subsystem3_init(void);
IMPORT ER subsystem4_init(void);
IMPORT ER subsystem5_init(void);

IMPORT ER subsystem1_start(void);
IMPORT ER subsystem2_start(void);
IMPORT ER subsystem3_start(void);
IMPORT ER subsystem4_start(void);
IMPORT ER subsystem5_start(void);

#if APP_TEST
IMPORT void subsystem1_test(void);
IMPORT void subsystem2_test(void);
IMPORT void subsystem3_test(void);
IMPORT void subsystem4_test(void);
IMPORT void subsystem5_test(void);
#endif

/* Print a readable message if a kernel call failed (negative error code) */
#define CHECK(er, what)                                                 \
    do {                                                                \
        INT check_er_ = (INT)(er);      /* evaluate once */             \
        if (check_er_ < E_OK) {                                         \
            tm_printf((UB*)"ERROR %s: %d\n", (what), check_er_);        \
        }                                                               \
    } while (0)

#endif /* APP_H */
