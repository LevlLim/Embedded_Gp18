/*
 * subsystem3.h
 *
 * Subsystem 3 -- IR line following and barcode decoding.
 * Buddy 3 (Zhi Kai), 2500466.
 *
 * Implements Statechart 3 of Design Review V2 section 6.3, which was
 * redrawn because the Week 6 version described barcode capture two
 * incompatible ways: a 1 ms ADC sampler AND "falling-edge timer input
 * capture".  An analogue ADC input cannot be edge-captured, so only one
 * of those could ever have been built.
 *
 * THE SINGLE AUTHORITATIVE METHOD IS PERIODIC ADC SAMPLING.  Bars are
 * found as threshold crossings in the sample stream and their widths are
 * measured from sample timestamps.  There is no edge capture anywhere in
 * this subsystem, and no module here touches the ADC: drivers/adc_sampler
 * owns it.
 */

#ifndef SUBSYSTEM3_H
#define SUBSYSTEM3_H

#include "../app.h"
#include "../msg_defs.h"
#include <stdint.h>
#include <stdbool.h>

/* ---------------------------------------------------------------------
 * Calibration and thresholds.  PROVISIONAL -- assumption A2 is still open
 * and these must be set from logged ADC values across the lit and shadowed
 * parts of the real track.
 * --------------------------------------------------------------------- */
#define S3_ADC_MAX              (4095u)
#define S3_CAL_SAMPLES          (64u)
#define S3_HYSTERESIS           (200u)  /* PROVISIONAL: ADC counts        */
#define S3_LOST_DEBOUNCE        (4u)    /* 4 x 5 ms = 20 ms of all-white  */

/* Barcode geometry.  Bars are classified by RELATIVE width against the
   narrowest bar in the symbol, so a change in vehicle speed does not
   invalidate the decode (assumption A1). */
#define S3_MAX_BARS             (24u)
#define S3_QUIET_ZONE_US        (12000u) /* PROVISIONAL: ends a symbol    */
#define S3_MIN_BAR_US           (600u)   /* PROVISIONAL: noise floor      */
#define S3_WIDE_RATIO_Q8        (512u)   /* wide if >= 2.0x the narrow    */

/*
 * line_error published as a three-field latest-value record.
 *
 * The Week 6 design used "volatile globals".  volatile stops the compiler
 * caching a value; it does NOT make a multi-field update atomic and gives
 * no ordering guarantee.  Motion Control needs the error, the time it was
 * taken, and whether it is usable, all consistent with each other -- so
 * this struct is written and read under a short interrupt-disabled window
 * and carries its own timestamp for the staleness check.
 */
typedef struct
{
    int8_t   error;         /* -63..+63, negative means line is to left */
    uint32_t timestamp_ms;
    bool     b_valid;
} s3_line_reading_t;

/* Read the latest line error.  Returns false if nothing published yet.
   The CALLER must still check timestamp_ms for staleness: this function
   returning true only means a reading exists, not that it is fresh. */
bool s3_read_line(s3_line_reading_t *p_out);

/* Current line sub-state, for telemetry. */
msg_line_state_t s3_get_line_state(void);

/* Begin / end active sensing.  Before START the subsystem samples and
   keeps thresholds live but publishes no error and decodes no barcode, so
   putting the car on the track triggers nothing. */
void s3_set_active(bool b_active);

/* Run the calibration pass.  Blocks for roughly S3_CAL_SAMPLES x 5 ms. */
ER s3_calibrate(void);

/* Barcode capture gate, kept in step with s3_set_active(). */
void s3_set_barcode_active(bool b_on);
bool s3_barcode_active(void);

/* Message buffer carrying packed barcode commands to the Controller. */
IMPORT ID mbf_barcode;

/* Private to subsystem 3. */
IMPORT ID   tid_line;
IMPORT ID   tid_barcode;
IMPORT void line_task(INT stacd, void *exinf);
IMPORT void barcode_task(INT stacd, void *exinf);

/* Exposed for the on-target test: classify a captured width sequence.
   Pure function, no hardware -- the host harness tests it directly. */
msg_barcode_cmd_t s3_decode_widths(const uint32_t *p_widths, uint8_t count,
                                   uint8_t *p_confidence);

#endif /* SUBSYSTEM3_H */
