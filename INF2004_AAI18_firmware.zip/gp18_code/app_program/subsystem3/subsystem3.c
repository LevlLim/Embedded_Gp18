/*
 * subsystem3.c
 *
 * Subsystem 3 -- line and barcode: creates its kernel objects and starts
 * its two tasks.
 *
 * This subsystem also brings up drivers/adc_sampler, because Buddy 3 owns
 * the ADC (Design Review V2 section 9).
 */

#include "subsystem3.h"
#include "../drivers/adc_sampler.h"

#define S3_BARCODE_QUEUE_DEPTH  (4)

static volatile bool b_barcode_active = false;

EXPORT ER subsystem3_init(void)
{
    T_CMBF cmbf = {0};
    ER     er;

    /* Bring up the ADC before anything tries to read a sample. */
    er = adc_sampler_init();
    if (er < E_OK)
    {
        return (er);
    }

    cmbf.mbfatr = TA_TFIFO;
    cmbf.bufsz  = (INT)(MSG_LEN_BARCODE * S3_BARCODE_QUEUE_DEPTH);
    cmbf.maxmsz = (INT)MSG_LEN_BARCODE;

    mbf_barcode = tk_cre_mbf(&cmbf);

    return ((mbf_barcode < E_OK) ? (ER)mbf_barcode : E_OK);
}

EXPORT ER subsystem3_start(void)
{
    tid_line = app_start_task(line_task, PRI_LINE_SENSOR,
                              TP_PRC1, "line_task");
    if (tid_line < E_OK)
    {
        return ((ER)tid_line);
    }

    tid_barcode = app_start_task(barcode_task, PRI_BARCODE,
                                 TP_PRC1, "barcode_task");

    return ((tid_barcode < E_OK) ? (ER)tid_barcode : E_OK);
}

/* Barcode capture follows the same active flag as line tracking. */
EXPORT bool s3_barcode_active(void)
{
    return (b_barcode_active);
}

/* s3_set_active() lives in line_sensor.c and also updates this flag. */
EXPORT void s3_set_barcode_active(bool b_on)
{
    b_barcode_active = b_on;
}
