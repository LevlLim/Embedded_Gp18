/*
 * subsystem3_test.c
 * On-target tests for subsystem 3 (line and barcode).
 */

#include "subsystem3.h"
#include "../drivers/adc_sampler.h"

#if APP_TEST

EXPORT void subsystem3_test(void)
{
    s3_line_reading_t reading;
    uint32_t          widths[4];
    uint8_t           confidence = 0u;
    msg_barcode_cmd_t decoded;

    tm_printf((UB*)"[TEST-S3] line and barcode\n");

    /* ---- the ADC is actually running ---- */
    adc_sampler_selftest();

    if (adc_sampler_overruns() > 0u)
    {
        tm_printf((UB*)"[TEST-S3] WARN: %d ADC overruns -- poll too slow\n",
                  (INT)adc_sampler_overruns());
    }

    /* ---- line error is published and timestamped ---- */
    s3_set_active(true);
    (void)tk_dly_tsk(200);

    if (s3_read_line(&reading))
    {
        tm_printf((UB*)"[TEST-S3] line err=%d valid=%d age=%d ms\n",
                  (INT)reading.error, (INT)reading.b_valid,
                  (INT)(app_now_ms() - reading.timestamp_ms));
    }
    else
    {
        tm_printf((UB*)"[TEST-S3] FAIL: no line reading published\n");
    }

    /* ---- barcode classification, synthetic widths ---- */
    widths[0] = 1000u; widths[1] = 1000u;
    widths[2] = 1000u; widths[3] = 2500u;     /* narrow narrow narrow WIDE */
    decoded = s3_decode_widths(widths, 4u, &confidence);
    tm_printf((UB*)"[TEST-S3] N,N,N,W -> cmd %d conf %d (expect 1 STRAIGHT)\n",
              (INT)decoded, (INT)confidence);

    widths[0] = 2500u; widths[1] = 1000u;
    widths[2] = 1000u; widths[3] = 1000u;     /* WIDE narrow narrow narrow */
    decoded = s3_decode_widths(widths, 4u, &confidence);
    tm_printf((UB*)"[TEST-S3] W,N,N,N -> cmd %d conf %d (expect 4 U_TURN)\n",
              (INT)decoded, (INT)confidence);

    /* All-noise widths must be rejected, not guessed. */
    widths[0] = 10u; widths[1] = 10u; widths[2] = 10u; widths[3] = 10u;
    decoded = s3_decode_widths(widths, 4u, &confidence);

    if (MSG_BC_INVALID == decoded)
    {
        tm_printf((UB*)"[TEST-S3] PASS: sub-threshold widths rejected\n");
    }
    else
    {
        tm_printf((UB*)"[TEST-S3] FAIL: noise decoded as command %d\n",
                  (INT)decoded);
    }

    s3_set_active(false);
}

#endif /* APP_TEST */
