/*
 * barcode_decoder.c
 *
 * Subsystem 3 -- the 1 ms barcode scan and decode.
 *
 * METHOD (and why it is the only one)
 * -----------------------------------
 * Every 1 ms this task drains the ADC FIFO and walks the new samples
 * looking for threshold crossings on ADC2 (GP28).  A crossing opens or
 * closes a bar; the bar's width is the difference between the two
 * crossing timestamps.  When a gap longer than the quiet zone appears,
 * the captured width sequence is classified.
 *
 * The Week 6 design also described "falling-edge timer input capture" for
 * this signal.  That cannot be built: GP28 is wired to the ADC and an
 * analogue input has no edge to capture.  Sampling is the method; the
 * contradiction is resolved by deleting the other description, not by
 * trying to support both.
 *
 * WIDTHS ARE RELATIVE.  Bars are classified narrow or wide against the
 * narrowest bar in the same symbol, so the decode survives a change in
 * vehicle speed.  That is what makes assumption A1 a question about
 * whether the SAMPLE RATE resolves the narrowest bar, not about holding
 * a constant speed.
 */

#include "subsystem3.h"
#include "../drivers/adc_sampler.h"
#include "../subsystem5/subsystem5.h"

EXPORT ID tid_barcode = 0;
EXPORT ID mbf_barcode = 0;

/* ---------------------------------------------------------------------
 * Private state
 * --------------------------------------------------------------------- */

static uint16_t threshold_barcode = (S3_ADC_MAX / 2u);
static bool     b_prev_dark       = false;
static uint32_t last_cross_us     = 0u;
static uint32_t last_seen_us      = 0u;

static uint32_t widths[S3_MAX_BARS];
static uint8_t  width_count = 0u;
static uint8_t  barcode_seq = 0u;

extern bool s3_barcode_active(void);

/* ---------------------------------------------------------------------
 * Private functions
 * --------------------------------------------------------------------- */

/*
 * Close the current symbol: classify it, publish it if valid, reset.
 */
static void finish_symbol(void)
{
    msg_barcode_t     message;
    msg_barcode_cmd_t decoded;
    uint8_t           confidence = 0u;
    uint8_t           buf[MSG_LEN_BARCODE];
    uint8_t           len;

    if (width_count >= 4u)
    {
        decoded = s3_decode_widths(widths, width_count, &confidence);

        /*
         * A failed decode is DISCARDED, never forwarded as a guess.  A
         * wrong turn command is far more damaging than a missed one: the
         * car leaves the track, whereas a missed command just continues
         * straight and can be re-read on the next pass.
         */
        if ((MSG_BC_INVALID != decoded) && (MSG_BC_NONE != decoded))
        {
            message.cmd        = decoded;
            message.confidence = confidence;
            message.seq        = (uint8_t)(barcode_seq & 0x03u);
            barcode_seq        = (uint8_t)(barcode_seq + 1u);

            len = msg_pack_barcode(&message, buf, sizeof(buf));
            if (0u != len)
            {
                (void)tk_snd_mbf(mbf_barcode, buf, (INT)len, TMO_POL);
                s5_post_event(S5_EVT_BARCODE);
            }
        }
    }

    width_count = 0u;
}

/* ---------------------------------------------------------------------
 * Public
 * --------------------------------------------------------------------- */

/*
 * Classify a width sequence into a command.
 *
 * Pure function: no hardware, no kernel objects, no globals.  That is
 * deliberate -- testing/host/ runs this directly on a PC with synthetic
 * width arrays, so the decode logic can be proven correct before the car
 * ever moves.
 *
 * Encoding used (a deliberately simple 4-bar scheme, to be replaced once
 * the real track's symbols are measured):
 *   the first four bars carry one bit each, narrow = 0, wide = 1
 *   0b0001 -> STRAIGHT   0b0010 -> LEFT
 *   0b0100 -> RIGHT      0b1000 -> U_TURN
 */
EXPORT msg_barcode_cmd_t s3_decode_widths(const uint32_t *p_widths,
                                          uint8_t count,
                                          uint8_t *p_confidence)
{
    uint32_t          narrowest = 0xFFFFFFFFu;
    uint32_t          ratio_q8;
    uint8_t           pattern = 0u;
    uint8_t           i;
    uint8_t           wide_count = 0u;
    msg_barcode_cmd_t result;

    if ((NULL == p_widths) || (count < 4u))
    {
        if (NULL != p_confidence) { *p_confidence = 0u; }
        return (MSG_BC_INVALID);
    }

    /* Narrowest bar in THIS symbol sets the reference. */
    for (i = 0u; i < count; i++)
    {
        if ((p_widths[i] > 0u) && (p_widths[i] < narrowest))
        {
            narrowest = p_widths[i];
        }
    }

    if ((0xFFFFFFFFu == narrowest) || (narrowest < S3_MIN_BAR_US))
    {
        /* Everything was noise-width: the sample rate did not resolve the
           bars at this speed.  This is the A1 failure mode. */
        if (NULL != p_confidence) { *p_confidence = 0u; }
        return (MSG_BC_INVALID);
    }

    for (i = 0u; i < 4u; i++)
    {
        ratio_q8 = (p_widths[i] * 256u) / narrowest;

        pattern = (uint8_t)(pattern << 1u);

        if (ratio_q8 >= S3_WIDE_RATIO_Q8)
        {
            pattern = (uint8_t)(pattern | 1u);
            wide_count++;
        }
    }

    switch (pattern)
    {
        case 0x01u: result = MSG_BC_STRAIGHT; break;
        case 0x02u: result = MSG_BC_LEFT;     break;
        case 0x04u: result = MSG_BC_RIGHT;    break;
        case 0x08u: result = MSG_BC_U_TURN;   break;
        default:    result = MSG_BC_INVALID;  break;
    }

    /*
     * Confidence: exactly one wide bar in a valid pattern is the ideal.
     * Anything else means the widths were ambiguous, and the Controller
     * can choose to ignore a low-confidence command.
     */
    if (NULL != p_confidence)
    {
        if (MSG_BC_INVALID == result)
        {
            *p_confidence = 0u;
        }
        else if (1u == wide_count)
        {
            *p_confidence = 7u;
        }
        else
        {
            *p_confidence = 3u;
        }
    }

    return (result);
}

EXPORT void barcode_task(INT stacd, void *exinf)
{
    adc_sample_t batch[32];
    uint8_t      got;
    uint8_t      i;
    bool         b_dark;
    uint32_t     width;

    (void)stacd;
    (void)exinf;

    for (;;)
    {
        /* Drain the hardware FIFO.  This task is the only caller of
           adc_sampler_poll(), because it runs at the shortest period. */
        (void)adc_sampler_poll();

        if (!s3_barcode_active())
        {
            width_count = 0u;
            (void)tk_dly_tsk(PERIOD_BARCODE_MS);
            continue;
        }

        got = adc_sampler_since(last_seen_us, batch,
                                (uint8_t)(sizeof(batch) / sizeof(batch[0])));

        for (i = 0u; i < got; i++)
        {
            last_seen_us = batch[i].timestamp_us;
            b_dark       = (batch[i].value > threshold_barcode);

            if (b_dark != b_prev_dark)
            {
                /* Threshold crossing: the previous bar just ended. */
                if (0u != last_cross_us)
                {
                    width = batch[i].timestamp_us - last_cross_us;

                    if ((width >= S3_MIN_BAR_US)
                        && (width_count < S3_MAX_BARS))
                    {
                        widths[width_count] = width;
                        width_count = (uint8_t)(width_count + 1u);
                    }
                }

                last_cross_us = batch[i].timestamp_us;
                b_prev_dark   = b_dark;
            }
            else if ((0u != last_cross_us)
                     && ((batch[i].timestamp_us - last_cross_us)
                         > S3_QUIET_ZONE_US))
            {
                /* Quiet zone: the symbol has ended. */
                finish_symbol();
                last_cross_us = 0u;
            }
            else
            {
                /* Still inside the current bar. */
            }
        }

        (void)tk_dly_tsk(PERIOD_BARCODE_MS);
    }
}
