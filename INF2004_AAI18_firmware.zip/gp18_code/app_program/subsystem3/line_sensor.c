/*
 * line_sensor.c
 *
 * Subsystem 3 -- the 5 ms line-following task and calibration.
 *
 * Reads the ADC ring buffer owned by drivers/adc_sampler.  Never touches
 * an ADC register, which is what keeps the shared-ADC conflict from
 * reappearing (Design Review V2 section 9).
 */

#include "subsystem3.h"
#include "../drivers/adc_sampler.h"
#include "../fault.h"
#include "../subsystem5/subsystem5.h"

EXPORT ID tid_line = 0;

/* ---------------------------------------------------------------------
 * Private state
 * --------------------------------------------------------------------- */

static s3_line_reading_t    published;
static msg_line_state_t     line_state  = MSG_LINE_IDLE;
static volatile bool        b_active    = false;

/* Per-channel thresholds, set by calibration. */
static uint16_t threshold_left   = (S3_ADC_MAX / 2u);
static uint16_t threshold_centre = (S3_ADC_MAX / 2u);

static uint8_t  lost_count = 0u;

/* ---------------------------------------------------------------------
 * Private functions
 * --------------------------------------------------------------------- */

/*
 * True when a channel reads "black line present".  The IR sensors used
 * here return a HIGHER ADC value over black (less reflected light), so
 * the comparison is "above threshold".  If the sensors turn out to be
 * wired the other way on the bench, invert here and nowhere else.
 */
static bool is_on_line(uint16_t value, uint16_t threshold)
{
    return (value > threshold);
}

/*
 * Compute a steering error from the two line sensors.
 *
 * With only two sensors the error is coarse -- this was flagged in the
 * Week 6 review as a key risk, and it remains one.  The mapping is:
 *   both on line   ->  0   (centred)
 *   centre only    ->  0
 *   left only      -> -N   (line has drifted left, steer left)
 *   neither        ->  hold the previous sign, and count toward LOST
 */
static int8_t compute_error(uint16_t v_left, uint16_t v_centre,
                            bool *p_any_line)
{
    static int8_t last_error = 0;
    bool          b_left     = is_on_line(v_left, threshold_left);
    bool          b_centre   = is_on_line(v_centre, threshold_centre);
    int8_t        error;

    if (b_centre && b_left)
    {
        error = -20;        /* drifting right of centre */
    }
    else if (b_centre)
    {
        error = 0;          /* centred */
    }
    else if (b_left)
    {
        error = -50;        /* well off to the left */
    }
    else
    {
        /* No line under either sensor.  Keep steering the way we last
           were, so the car continues its arc back toward the line rather
           than snapping straight. */
        error = (last_error < 0) ? -63 : 63;
        *p_any_line = false;
        return (error);
    }

    last_error  = error;
    *p_any_line = true;

    return (error);
}

/*
 * Publish a reading.  Written under interrupt disable so that the three
 * fields are mutually consistent for the reader.
 */
static void publish_reading(int8_t error, bool b_valid)
{
    UINT imask;

    DI(imask);
    published.error        = error;
    published.timestamp_ms = app_now_ms();
    published.b_valid      = b_valid;
    EI(imask);
}

/* ---------------------------------------------------------------------
 * Public
 * --------------------------------------------------------------------- */

EXPORT ER s3_calibrate(void)
{
    adc_sample_t sample;
    uint32_t     sum_left    = 0u;
    uint32_t     sum_centre  = 0u;
    uint16_t     min_left    = (uint16_t)S3_ADC_MAX;
    uint16_t     max_left    = 0u;
    uint32_t     taken       = 0u;
    uint32_t     i;

    line_state = MSG_LINE_CAL;

    for (i = 0u; i < S3_CAL_SAMPLES; i++)
    {
        if (adc_sampler_read(ADC_CH_LINE_L, &sample))
        {
            sum_left += sample.value;

            if (sample.value < min_left) { min_left = sample.value; }
            if (sample.value > max_left) { max_left = sample.value; }
        }
        if (adc_sampler_read(ADC_CH_LINE_C, &sample))
        {
            sum_centre += sample.value;
        }

        taken++;
        (void)tk_dly_tsk(PERIOD_LINE_MS);
    }

    if (0u == taken)
    {
        return (E_IO);
    }

    /*
     * Midpoint between the extremes seen during calibration, offset by the
     * hysteresis band.  This assumes the calibration pass saw both black
     * and white -- the car must be moved across the line while it runs.
     */
    threshold_left   = (uint16_t)((sum_left / taken) + S3_HYSTERESIS);
    threshold_centre = (uint16_t)((sum_centre / taken) + S3_HYSTERESIS);

    tm_printf((UB*)"[S3] cal: thr_L=%d thr_C=%d (spread L %d..%d)\n",
              (INT)threshold_left, (INT)threshold_centre,
              (INT)min_left, (INT)max_left);

    /*
     * A tiny spread means the sensors never saw both surfaces, so the
     * thresholds are meaningless.  Fail loudly rather than driving on a
     * calibration that cannot work (assumption A2).
     */
    if ((max_left - min_left) < (uint16_t)(S3_HYSTERESIS * 2u))
    {
        tm_printf((UB*)"[S3] CAL FAILED: insufficient contrast\n");
        line_state = MSG_LINE_IDLE;
        return (E_IO);
    }

    line_state = MSG_LINE_IDLE;

    return (E_OK);
}

EXPORT void line_task(INT stacd, void *exinf)
{
    adc_sample_t s_left;
    adc_sample_t s_centre;
    int8_t       error;
    bool         b_any_line;

    (void)stacd;
    (void)exinf;

    for (;;)
    {
        if (!b_active)
        {
            line_state = MSG_LINE_IDLE;
            publish_reading(0, false);
            (void)tk_dly_tsk(PERIOD_LINE_MS);
            continue;
        }

        if (adc_sampler_read(ADC_CH_LINE_L, &s_left)
            && adc_sampler_read(ADC_CH_LINE_C, &s_centre))
        {
            b_any_line = true;
            error      = compute_error(s_left.value, s_centre.value,
                                       &b_any_line);

            if (b_any_line)
            {
                lost_count = 0u;
                line_state = MSG_LINE_TRACK;
                publish_reading(error, true);
            }
            else
            {
                if (lost_count < S3_LOST_DEBOUNCE)
                {
                    lost_count = (uint8_t)(lost_count + 1u);
                    /* Still within the debounce window: keep steering on
                       the last known direction, still marked valid. */
                    publish_reading(error, true);
                }
                else
                {
                    /* Confirmed loss.  Publish invalid so Motion Control
                       decelerates, and tell the Controller, which decides
                       between LINE_SEARCH and a stop.  This task never
                       commands the motors itself. */
                    line_state = MSG_LINE_LOST;
                    publish_reading(error, false);
                    s5_post_event(S5_EVT_LINE_LOST);
                }
            }
        }
        else
        {
            /* No ADC sample at all: the sampler is not running. */
            publish_reading(0, false);
        }

        (void)tk_dly_tsk(PERIOD_LINE_MS);
    }
}

EXPORT bool s3_read_line(s3_line_reading_t *p_out)
{
    UINT imask;
    bool b_ok = false;

    if (NULL == p_out)
    {
        return (false);
    }

    DI(imask);
    if (0u != published.timestamp_ms)
    {
        *p_out = published;
        b_ok   = true;
    }
    EI(imask);

    return (b_ok);
}

EXPORT msg_line_state_t s3_get_line_state(void)
{
    return (line_state);
}

EXPORT void s3_set_active(bool b_on)
{
    b_active   = b_on;
    lost_count = 0u;

    /* Barcode capture follows line tracking: both are off until START. */
    s3_set_barcode_active(b_on);
}
