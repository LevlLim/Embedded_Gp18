/*
 * imu_terrain.c
 *
 * Subsystem 4 -- IMU task: calibration, hump sequence, collision, tilt.
 *
 * Runs every 10 ms with a 4 ms worst-case budget (NFR11).  Every I2C call
 * carries a timeout, so a dead sensor cannot spin this High-priority task:
 * it fails, counts the failure, and after S4_IMU_FAIL_LIMIT consecutive
 * failures raises FAULT_IMU and enters the defined degraded behaviour.
 */

#include "subsystem4.h"
#include "../fault.h"
#include "../drivers/i2c0.h"
#include "../subsystem2/subsystem2.h"
#include "../subsystem5/subsystem5.h"

EXPORT ID tid_imu = 0;

/* ---------------------------------------------------------------------
 * Private state
 * --------------------------------------------------------------------- */

static volatile s4_state_t state = S4_INIT_CAL;
static volatile bool       b_active = false;

static int16_t  offset_x = 0;
static int16_t  offset_y = 0;
static int16_t  offset_z = 0;

static int8_t   tilt_deg       = 0;
static uint8_t  debounce       = 0u;
static int32_t  hump_height_um = 0;
static int32_t  hump_start_mm  = 0;
static uint32_t hump_start_ms  = 0u;

static uint8_t  run_max_peak_mm = 0u;
static bool     b_peak_sat      = false;
static bool     b_run_invalid   = false;

static uint8_t  consecutive_fail = 0u;

/*
 * sin(x) in Q8 for 0..45 degrees, one entry per degree.  A lookup keeps
 * the 10 ms path free of floating point, which the Cortex-M0+ has no
 * hardware for (Barr-C 5.4a).  Beyond 45 degrees the car is in
 * TILT_FAULT, so the table does not need to go further.
 */
static const uint8_t sin_q8[46] =
{
      0,   4,   9,  13,  18,  22,  27,  31,  36,  40,
     44,  49,  53,  58,  62,  66,  71,  75,  79,  83,
     87,  92,  96, 100, 104, 108, 112, 116, 120, 124,
    128, 132, 136, 139, 143, 147, 150, 154, 158, 161,
    165, 168, 171, 175, 178, 181
};

/* ---------------------------------------------------------------------
 * Private functions
 * --------------------------------------------------------------------- */

/*
 * Read one three-axis sample.  Returns E_OK, or an error if the bus or
 * the sensor did not respond.
 */
static ER read_accel(int16_t *p_x, int16_t *p_y, int16_t *p_z)
{
    uint8_t raw[6];
    ER      er;

    er = i2c0_read_burst(S4_ACCEL_ADDR,
                         (uint8_t)(S4_REG_OUT_X_L | S4_AUTO_INC),
                         raw, (uint8_t)sizeof(raw));

    if (er >= E_OK)
    {
        /* Little-endian 16-bit, left-justified by the part. */
        *p_x = (int16_t)((uint16_t)raw[0] | ((uint16_t)raw[1] << 8u));
        *p_y = (int16_t)((uint16_t)raw[2] | ((uint16_t)raw[3] << 8u));
        *p_z = (int16_t)((uint16_t)raw[4] | ((uint16_t)raw[5] << 8u));
    }

    return (er);
}

/*
 * Convert a raw axis reading to milli-g.  At +/-2 g full scale over a
 * signed 16-bit range, one LSB is about 0.061 mg.
 */
static int32_t to_milli_g(int16_t raw)
{
    return (((int32_t)raw * 2000) / 32768);
}

/*
 * Pitch angle from the accelerometer alone.
 *
 * KNOWN LIMITATION, carried from the Week 6 review: this is corrupted by
 * linear acceleration, because the sensor cannot tell gravity from the
 * car accelerating.  There is no gyroscope to fuse with.  This is why
 * FR5's +/-5 mm is ambitious and why assumption A7 must be validated on
 * the real hump before the tolerance is believed.
 *
 * The small-angle approximation below is good to about 1 degree out to
 * 30 degrees, which is the range that matters before TILT_FAULT.
 */
static int8_t compute_pitch_deg(int32_t ax_mg, int32_t az_mg)
{
    int32_t degrees;

    if (0 == az_mg)
    {
        return (0);
    }

    /* atan(x) ~= x for small x; 57 is 180/pi rounded. */
    degrees = (ax_mg * 57) / ((az_mg < 0) ? -az_mg : az_mg);

    if (degrees > 90)       { degrees = 90; }
    else if (degrees < -90) { degrees = -90; }
    else                    { /* in range */ }

    return ((int8_t)degrees);
}

/*
 * Close out a hump and decide whether to believe it.
 */
static void finish_hump(void)
{
    int32_t  height_mm = hump_height_um / 1000;
    uint32_t duration  = app_now_ms() - hump_start_ms;

    /*
     * Validate before reporting.  A measurement outside the plausible
     * range, or one that took implausibly long, is DISCARDED rather than
     * published with a wrong value -- a wrong peak height fails FR5 just
     * as surely as a missing one, but is harder to notice.
     */
    if ((height_mm > 0) && (height_mm < 200)
        && (duration < S4_HUMP_TIMEOUT_MS))
    {
        if (height_mm > (int32_t)MSG_MAX_HUMP_MM)
        {
            /* Saturate and FLAG it (design rule R5). */
            run_max_peak_mm = (uint8_t)MSG_MAX_HUMP_MM;
            b_peak_sat      = true;
        }
        else if ((uint8_t)height_mm > run_max_peak_mm)
        {
            run_max_peak_mm = (uint8_t)height_mm;
        }
        else
        {
            /* Not a new maximum. */
        }

        s5_post_event(S5_EVT_HUMP);
    }

    hump_height_um = 0;
}

/*
 * The hump sequence state machine.
 *
 * Split out of imu_task() so that each stays within the 100-line limit of
 * Barr-C 6.2a and so that the sequence logic can be read on its own: a
 * hump is only believed if nose-up, crest, nose-down and level occur in
 * that order.
 */
static void step_hump_machine(int32_t travelled)
{
    switch (state)
    {
        case S4_IDLE:
        case S4_LEVEL_RUN:
            state = S4_LEVEL_RUN;

            if (tilt_deg >= S4_HUMP_START_DEG)
            {
                debounce = (uint8_t)(debounce + 1u);

                if (debounce >= S4_DEBOUNCE_SAMPLES)
                {
                    state          = S4_HUMP_RISING;
                    hump_height_um = 0;
                    hump_start_ms  = app_now_ms();
                    debounce       = 0u;
                }
            }
            else
            {
                debounce = 0u;
            }
            break;

        case S4_HUMP_RISING:
            hump_height_um += s4_height_increment_um(tilt_deg, travelled);

            if (tilt_deg < S4_HUMP_LEVEL_DEG)
            {
                state = S4_HUMP_CREST;
            }
            break;

        case S4_HUMP_CREST:
            if (tilt_deg <= -S4_HUMP_START_DEG)
            {
                state = S4_HUMP_FALLING;
            }
            else if ((app_now_ms() - hump_start_ms) > S4_HUMP_TIMEOUT_MS)
            {
                /* Never came down: not a hump.  Drop it. */
                hump_height_um = 0;
                state          = S4_LEVEL_RUN;
            }
            else
            {
                /* Still on the crest. */
            }
            break;

        case S4_HUMP_FALLING:
            if ((tilt_deg > -S4_HUMP_LEVEL_DEG)
                && (tilt_deg < S4_HUMP_LEVEL_DEG))
            {
                finish_hump();
                state = S4_LEVEL_RUN;
            }
            break;

        case S4_COLLISION:
        case S4_TILT_FAULT:
            /* Latched.  Only a Controller RESET leaves these, which
               arrives as s4_reset_run(). */
            break;

        default:
            state = S4_LEVEL_RUN;
            break;
    }
}

/* ---------------------------------------------------------------------
 * Public
 * --------------------------------------------------------------------- */

EXPORT int32_t s4_height_increment_um(int8_t tilt, int32_t distance_mm)
{
    int32_t magnitude = (tilt < 0) ? -(int32_t)tilt : (int32_t)tilt;
    int32_t sine_q8;

    if (magnitude > 45)
    {
        magnitude = 45;
    }

    sine_q8 = (int32_t)sin_q8[magnitude];

    /* distance in mm x sin -> micrometres, keeping integer precision. */
    return ((distance_mm * sine_q8 * 1000) / 256);
}

EXPORT void imu_task(INT stacd, void *exinf)
{
    int16_t  raw_x;
    int16_t  raw_y;
    int16_t  raw_z;
    int32_t  ax_mg;
    int32_t  az_mg;
    int32_t  magnitude_mg;
    int32_t  distance_now;
    int32_t  travelled;
    int32_t  speed_l;
    int32_t  speed_r;
    uint8_t  i;
    ER       er;

    (void)stacd;
    (void)exinf;

    /* ---- INIT_CAL: offsets with the car held still ---- */
    state = S4_INIT_CAL;

    for (i = 0u; i < 3u; i++)
    {
        er = read_accel(&raw_x, &raw_y, &raw_z);
        if (er >= E_OK)
        {
            offset_x = raw_x;
            offset_y = raw_y;
            offset_z = raw_z;
            break;
        }
        (void)tk_dly_tsk(100);
    }

    if (er < E_OK)
    {
        fault_set(FAULT_IMU);
        b_run_invalid = true;
        state         = S4_IMU_FAULT;
    }
    else
    {
        state = S4_IDLE;
    }

    hump_start_mm = s2_get_distance_mm();

    for (;;)
    {
        er = read_accel(&raw_x, &raw_y, &raw_z);

        if (er < E_OK)
        {
            if (consecutive_fail < S4_IMU_FAIL_LIMIT)
            {
                consecutive_fail = (uint8_t)(consecutive_fail + 1u);
            }
            else if (S4_IMU_FAULT != state)
            {
                /*
                 * DEFINED SAFE BEHAVIOUR (was undefined in Week 6).
                 * IMU_FAULT is a DEGRADE fault, not an E-STOP: losing
                 * hump measurement is not itself dangerous, so the car
                 * does NOT brake.  But collision detection is now gone,
                 * so the Controller caps the speed and this run's FR4/FR5
                 * reporting is marked invalid.  The run finishes rather
                 * than being abandoned mid-track.
                 */
                fault_set(FAULT_IMU);
                b_run_invalid = true;
                state         = S4_IMU_FAULT;
            }
            else
            {
                /* Already reported. */
            }

            (void)tk_dly_tsk(PERIOD_IMU_MS);
            continue;
        }

        consecutive_fail = 0u;

        if (S4_IMU_FAULT == state)
        {
            /* The sensor came back.  Stay degraded for this run: the data
               already missed is gone, so the peak cannot be trusted. */
            state = S4_LEVEL_RUN;
        }

        ax_mg = to_milli_g((int16_t)(raw_x - offset_x));
        az_mg = to_milli_g(raw_z);

        magnitude_mg = (ax_mg < 0) ? -ax_mg : ax_mg;
        tilt_deg     = compute_pitch_deg(ax_mg, az_mg);

        if (!b_active)
        {
            state = S4_IDLE;
            (void)tk_dly_tsk(PERIOD_IMU_MS);
            continue;
        }

        /* ---- collision, checked in every active state ---- */
        s2_get_speeds(&speed_l, &speed_r);

        if (magnitude_mg > S4_IMPACT_MILLI_G)
        {
            /*
             * The encoder-motion gate separates a real impact from the
             * car being picked up or knocked at rest (assumption A8).
             */
            if ((0 != speed_l) || (0 != speed_r))
            {
                fault_set(FAULT_COLLISION);
                state = S4_COLLISION;
                (void)tk_dly_tsk(PERIOD_IMU_MS);
                continue;
            }
        }

        /* ---- sustained extreme lean ---- */
        if ((tilt_deg > S4_TILT_FAULT_DEG) || (tilt_deg < -S4_TILT_FAULT_DEG))
        {
            if (debounce < S4_DEBOUNCE_SAMPLES)
            {
                debounce = (uint8_t)(debounce + 1u);
            }
            else
            {
                fault_set(FAULT_TILT);
                state = S4_TILT_FAULT;
                (void)tk_dly_tsk(PERIOD_IMU_MS);
                continue;
            }
        }

        /* ---- hump sequence ---- */
        distance_now = s2_get_distance_mm();
        travelled    = distance_now - hump_start_mm;
        hump_start_mm = distance_now;

        step_hump_machine(travelled);

        (void)tk_dly_tsk(PERIOD_IMU_MS);
    }
}

EXPORT uint8_t s4_get_run_max_peak_mm(void)  { return (run_max_peak_mm); }
EXPORT bool    s4_peak_saturated(void)       { return (b_peak_sat); }
EXPORT int8_t  s4_get_tilt_deg(void)         { return (tilt_deg); }
EXPORT s4_state_t s4_get_state(void)         { return (state); }
EXPORT bool    s4_run_data_invalid(void)     { return (b_run_invalid); }

EXPORT void s4_set_active(bool b_on)
{
    b_active = b_on;
    debounce = 0u;
}

EXPORT void s4_reset_run(void)
{
    run_max_peak_mm = 0u;
    b_peak_sat      = false;
    b_run_invalid   = false;
    hump_height_um  = 0;
    debounce        = 0u;
    hump_start_mm   = s2_get_distance_mm();

    if ((S4_COLLISION == state) || (S4_TILT_FAULT == state))
    {
        state = S4_IDLE;
    }
}
