/*
 * subsystem4_test.c
 * On-target tests for subsystem 4 (IMU and terrain).
 */

#include "subsystem4.h"
#include "../drivers/i2c0.h"
#include "../fault.h"

#if APP_TEST

EXPORT void subsystem4_test(void)
{
    uint8_t who = 0u;
    int32_t increment;

    tm_printf((UB*)"[TEST-S4] IMU and terrain\n");

    /* ---- the sensor answers ---- */
    if (i2c0_read_reg(S4_ACCEL_ADDR, S4_REG_WHO_AM_I, &who) >= E_OK)
    {
        tm_printf((UB*)"[TEST-S4] PASS: IMU WHO_AM_I = 0x%02x\n", (INT)who);
    }
    else
    {
        tm_printf((UB*)"[TEST-S4] FAIL: IMU silent -- check I2C0 wiring\n");
    }

    tm_printf((UB*)"[TEST-S4] i2c errors so far = %d\n",
              (INT)i2c0_error_count());

    /* ---- height accumulation is monotonic and signed correctly ---- */
    increment = s4_height_increment_um(10, 100);
    tm_printf((UB*)"[TEST-S4] 10 deg over 100 mm = %d um (expect ~17400)\n",
              (INT)increment);

    if (increment <= 0)
    {
        tm_printf((UB*)"[TEST-S4] FAIL: positive tilt gave no rise\n");
    }

    /* A level chassis must contribute no height, or a flat run would
       accumulate a phantom hump. */
    increment = s4_height_increment_um(0, 1000);

    if (0 == increment)
    {
        tm_printf((UB*)"[TEST-S4] PASS: level chassis adds no height\n");
    }
    else
    {
        tm_printf((UB*)"[TEST-S4] FAIL: level added %d um\n", (INT)increment);
    }

    tm_printf((UB*)"[TEST-S4] tilt now %d deg, state %d\n",
              (INT)s4_get_tilt_deg(), (INT)s4_get_state());
}

#endif /* APP_TEST */
