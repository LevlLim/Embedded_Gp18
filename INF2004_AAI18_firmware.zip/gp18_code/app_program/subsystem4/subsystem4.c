/*
 * subsystem4.c
 *
 * Subsystem 4 -- IMU / Terrain: brings up I2C0 and the accelerometer,
 * then starts its task.
 *
 * This subsystem is the sole user of I2C0, which is why the Week 6
 * decision to reject bus-sharing synchronisation stands: there is no
 * second claimant to arbitrate with.
 */

#include "subsystem4.h"
#include "../drivers/i2c0.h"
#include "../fault.h"

EXPORT ER subsystem4_init(void)
{
    uint8_t who = 0u;
    ER      er;

    er = i2c0_init();
    if (er < E_OK)
    {
        return (er);
    }

    /*
     * Identify the part before configuring it.  A wrong or absent
     * WHO_AM_I means the bus is miswired or the address is wrong, and it
     * is far better to say so at startup than to spend a bench session
     * wondering why hump detection never fires.
     */
    er = i2c0_read_reg(S4_ACCEL_ADDR, S4_REG_WHO_AM_I, &who);
    if (er < E_OK)
    {
        tm_printf((UB*)"[S4] IMU not responding at 0x%02x\n",
                  (INT)S4_ACCEL_ADDR);
        fault_set(FAULT_IMU);
        /* Not a fatal error for the system: the car can still follow the
           line.  The Controller degrades, per the Fault Table. */
        return (E_OK);
    }

    tm_printf((UB*)"[S4] IMU WHO_AM_I = 0x%02x\n", (INT)who);

    /*
     * CTRL1: 400 Hz output data rate, all three axes enabled.
     * 400 Hz into the FIFO, drained every 10 ms, means a wall impact
     * lasting only a few milliseconds still lands in the block -- a plain
     * 100 Hz poll would miss it and FR11 could not be demonstrated.
     */
    (void)i2c0_write_reg(S4_ACCEL_ADDR, S4_REG_CTRL1, 0x77u);

    /* CTRL4: +/-2 g full scale, high resolution. */
    (void)i2c0_write_reg(S4_ACCEL_ADDR, S4_REG_CTRL4, 0x08u);

    /* CTRL5 / FIFO_CTRL: enable the FIFO in stream mode. */
    (void)i2c0_write_reg(S4_ACCEL_ADDR, S4_REG_CTRL5, 0x40u);
    (void)i2c0_write_reg(S4_ACCEL_ADDR, S4_REG_FIFO_CTRL, 0x80u);

    return (E_OK);
}

EXPORT ER subsystem4_start(void)
{
    tid_imu = app_start_task(imu_task, PRI_IMU_TERRAIN,
                             TP_PRC1, "imu_task");

    return ((tid_imu < E_OK) ? (ER)tid_imu : E_OK);
}
