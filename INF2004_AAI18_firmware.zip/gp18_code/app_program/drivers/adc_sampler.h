/*
 * adc_sampler.h
 *
 * Group AAI18 -- sole owner of the RP2040 ADC and its input mux.
 *
 * OWNERSHIP: Buddy 3.  Design Review V2 section 3 and section 9.
 *
 * WHY THIS MODULE EXISTS
 * ----------------------
 * The RP2040 has ONE ADC behind a shared mux.  The Week 6 design had the
 * Line Sensor task reading GP26/GP27 every 5 ms while a separate 1 ms
 * handler read GP28 for barcode.  Two independent claimants switching the
 * mux corrupt each other's conversions, and the corruption is silent and
 * intermittent -- the worst kind to find at integration.
 *
 * The fix is structural rather than procedural: this module owns the
 * peripheral, free-runs it in round-robin across ADC0/ADC1/ADC2, and
 * publishes timestamped samples in a ring buffer.  Line Sensor and Barcode
 * Decoder read the buffer.  Neither touches an ADC register, so the
 * contention cannot reappear by accident.
 *
 * CONCURRENCY
 * -----------
 * The ring buffer has exactly one writer (adc_sampler_poll(), called from
 * the Barcode task's 1 ms tick) and several readers.  Each channel's
 * latest value is a single 16-bit word plus a 32-bit timestamp, published
 * in that order with the write index advanced last, so a reader that gets
 * a torn pair sees the OLD sample rather than a mixture.
 *
 * NOT PACKED, DELIBERATELY: the sample timestamps are native uint32_t.
 * Design Review V2 section 7.4 records this exclusion -- a narrowed
 * timestamp wraps inside a measurement window and turns a timing
 * calculation into a plausible but wrong result.
 */

#ifndef ADC_SAMPLER_H
#define ADC_SAMPLER_H

#include "../app.h"
#include <stdint.h>
#include <stdbool.h>

#define ADC_CH_LINE_L       (0u)    /* GP26 */
#define ADC_CH_LINE_C       (1u)    /* GP27 */
#define ADC_CH_BARCODE      (2u)    /* GP28 */
#define ADC_CH_COUNT        (3u)

/* Ring of recent barcode samples.  At 1 ms per poll this holds 256 ms of
   history, which is long enough for the widest barcode symbol at the
   speeds assumption A1 allows. */
#define ADC_RING_LEN        (256u)

typedef struct
{
    uint16_t value;         /* 12-bit right-aligned conversion result */
    uint32_t timestamp_us;  /* free-running microsecond timer        */
} adc_sample_t;

/*
 * Configure the ADC: enable the clock, release the reset, set GP26..GP28
 * to analogue mode, enable the FIFO and start free-running round-robin
 * conversion across the three channels.  Call once from phase 1.
 */
ER adc_sampler_init(void);

/*
 * Drain the hardware FIFO into the per-channel latest values and the
 * barcode ring.  Called from the 1 ms barcode tick, which is the fastest
 * consumer; the FIFO is 4 deep and the round-robin produces roughly one
 * sample per channel per 6 us, so draining every 1 ms keeps it from
 * overflowing only because we drain the whole FIFO each time.
 *
 * Returns the number of samples drained.
 */
uint8_t adc_sampler_poll(void);

/* Latest value for one channel.  Returns false if no sample yet. */
bool adc_sampler_read(uint8_t channel, adc_sample_t *p_out);

/*
 * Copy up to max_out barcode samples newer than after_us into p_out,
 * oldest first.  Returns how many were copied.  The Barcode Decoder uses
 * this to walk the sample stream looking for threshold crossings -- this
 * is the ONLY barcode capture method in the design.  There is no edge
 * capture: an analogue ADC input cannot be edge-captured, which is the
 * contradiction the Week 6 review raised.
 */
uint8_t adc_sampler_since(uint32_t after_us, adc_sample_t *p_out,
                          uint8_t max_out);

/* Count of FIFO overrun events seen since init, published in telemetry so
   a sampling problem is visible rather than silent. */
uint32_t adc_sampler_overruns(void);

/* Register dump for bring-up.  Prints CS, FCS and DIV so the first bench
   session can confirm the peripheral is actually running. */
void adc_sampler_selftest(void);

#endif /* ADC_SAMPLER_H */
