/*
 * i2c0.c
 *
 * Group AAI18 -- polled I2C0 master (RP2040 / Synopsys DW_apb_i2c).
 */

#include "i2c0.h"
#include "rp2040_regs.h"

static uint32_t error_count   = 0u;
static bool     b_initialised = false;

/* ---------------------------------------------------------------------
 * Private
 * --------------------------------------------------------------------- */

/*
 * Route one GPIO to the I2C peripheral and enable its input buffer with a
 * pull-up.  The Robo Pico carries external pull-ups on the IMU bus, but
 * enabling the internal ones costs nothing and lets the bus work on a
 * bare breadboard during bring-up.
 */
static void i2c_pin_setup(uint32_t gpio)
{
    const uint32_t pads_base = 0x4001C000u;
    uint32_t       pad_reg   = pads_base + 0x04u + (4u * gpio);

    /* Input enable, pull-up on, pull-down off, output disable off. */
    set_w(pad_reg, (1u << 6u) | (1u << 3u));
    clr_w(pad_reg, (1u << 2u) | (1u << 7u));

    /* FUNCSEL = I2C */
    out_w(GPIO_CTRL(gpio), GPIO_FUNC_I2C);
}

/*
 * Abort the current transfer and clear the sticky abort source, so the
 * next call starts from a known state rather than inheriting an error.
 */
static void i2c_recover(void)
{
    (void)in_w(I2C_CLR_TX_ABRT);
    out_w(I2C_ENABLE, 0u);
    out_w(I2C_ENABLE, 1u);
    error_count = error_count + 1u;
}

/* ---------------------------------------------------------------------
 * Public
 * --------------------------------------------------------------------- */

EXPORT ER i2c0_init(void)
{
    if (b_initialised)
    {
        return (E_OK);
    }

    /* Release I2C0 from reset. */
    clr_w(RESETS_RESET, RESETS_RESET_I2C0);
    while (0u == (in_w(RESETS_RESET_DONE) & RESETS_RESET_I2C0))
    {
        /* Runs once at init, before any task exists. */
    }

    out_w(I2C_ENABLE, 0u);

    out_w(I2C_CON, I2C_CON_MASTER_MODE
                 | I2C_CON_SPEED_FAST
                 | I2C_CON_7BIT_ADDR
                 | I2C_CON_RESTART_EN
                 | I2C_CON_SLAVE_DISABLE
                 | I2C_CON_TX_EMPTY_CTRL);

    /*
     * 400 kHz from a 125 MHz system clock: one bit period is 312.5 clocks.
     * The datasheet's split is roughly 1:2 high:low for fast mode.
     * HCNT + LCNT + spike length overhead must total that period.
     */
    out_w(I2C_FS_SPKLEN,  7u);
    out_w(I2C_FS_SCL_HCNT, 95u);
    out_w(I2C_FS_SCL_LCNT, 205u);

    out_w(I2C_TX_TL, 0u);
    out_w(I2C_RX_TL, 0u);

    out_w(I2C_ENABLE, 1u);

    i2c_pin_setup(PIN_IMU_SDA);
    i2c_pin_setup(PIN_IMU_SCL);

    b_initialised = true;

    return (E_OK);
}

EXPORT ER i2c0_write_read(uint8_t addr, const uint8_t *p_tx, uint8_t tx_len,
                          uint8_t *p_rx, uint8_t rx_len, uint32_t timeout_us)
{
    uint32_t deadline;
    uint32_t cmd;
    uint8_t  i;
    uint8_t  received = 0u;

    if (!b_initialised)
    {
        return (E_OBJ);
    }
    if (((NULL == p_tx) && (0u != tx_len))
        || ((NULL == p_rx) && (0u != rx_len)))
    {
        return (E_PAR);
    }

    deadline = RP2040_NOW_US() + timeout_us;

    /* Target address must be set with the peripheral disabled. */
    out_w(I2C_ENABLE, 0u);
    out_w(I2C_TAR, (uint32_t)addr);
    out_w(I2C_ENABLE, 1u);

    /* ---- write phase ---- */
    for (i = 0u; i < tx_len; i++)
    {
        while (0u == (in_w(I2C_STATUS) & I2C_STATUS_TFNF))
        {
            if ((int32_t)(RP2040_NOW_US() - deadline) >= 0)
            {
                i2c_recover();
                return (E_TMOUT);
            }
        }

        cmd = (uint32_t)p_tx[i];

        /* If there is no read phase, the last written byte ends with STOP. */
        if ((0u == rx_len) && (i == (tx_len - 1u)))
        {
            cmd |= I2C_DATA_CMD_STOP;
        }

        out_w(I2C_DATA_CMD, cmd);
    }

    /* ---- read phase ---- */
    for (i = 0u; i < rx_len; i++)
    {
        while (0u == (in_w(I2C_STATUS) & I2C_STATUS_TFNF))
        {
            if ((int32_t)(RP2040_NOW_US() - deadline) >= 0)
            {
                i2c_recover();
                return (E_TMOUT);
            }
        }

        cmd = I2C_DATA_CMD_READ;

        /* Repeated START before the first read byte, STOP after the last. */
        if (0u == i)
        {
            cmd |= I2C_DATA_CMD_RESTART;
        }
        if (i == (rx_len - 1u))
        {
            cmd |= I2C_DATA_CMD_STOP;
        }

        out_w(I2C_DATA_CMD, cmd);
    }

    /* ---- drain the receive FIFO ---- */
    while (received < rx_len)
    {
        if (0u != (in_w(I2C_RAW_INTR_STAT) & I2C_RAW_TX_ABRT))
        {
            /* The slave did not acknowledge: no device, or wrong address. */
            i2c_recover();
            return (E_IO);
        }

        if (0u != (in_w(I2C_STATUS) & I2C_STATUS_RFNE))
        {
            p_rx[received] = (uint8_t)(in_w(I2C_DATA_CMD) & 0xFFu);
            received       = (uint8_t)(received + 1u);
        }
        else if ((int32_t)(RP2040_NOW_US() - deadline) >= 0)
        {
            i2c_recover();
            return (E_TMOUT);
        }
        else
        {
            /* Keep polling. */
        }
    }

    /* A write-only transfer still has to reach its STOP before returning,
       or the next call collides with this one. */
    if (0u == rx_len)
    {
        while (0u == (in_w(I2C_RAW_INTR_STAT) & I2C_RAW_STOP_DET))
        {
            if (0u != (in_w(I2C_RAW_INTR_STAT) & I2C_RAW_TX_ABRT))
            {
                i2c_recover();
                return (E_IO);
            }
            if ((int32_t)(RP2040_NOW_US() - deadline) >= 0)
            {
                i2c_recover();
                return (E_TMOUT);
            }
        }
        (void)in_w(I2C_CLR_INTR);
    }

    return (E_OK);
}

EXPORT ER i2c0_read_reg(uint8_t addr, uint8_t reg, uint8_t *p_value)
{
    return (i2c0_write_read(addr, &reg, 1u, p_value, 1u, I2C0_TIMEOUT_US));
}

EXPORT ER i2c0_read_burst(uint8_t addr, uint8_t reg, uint8_t *p_buf,
                          uint8_t len)
{
    /* Many accelerometers require the MSB of the register address set to
       auto-increment during a burst read.  The IMU driver passes the
       already-decorated register value, so nothing is added here. */
    return (i2c0_write_read(addr, &reg, 1u, p_buf, len, I2C0_TIMEOUT_US));
}

EXPORT ER i2c0_write_reg(uint8_t addr, uint8_t reg, uint8_t value)
{
    uint8_t tx[2];

    tx[0] = reg;
    tx[1] = value;

    return (i2c0_write_read(addr, tx, 2u, NULL, 0u, I2C0_TIMEOUT_US));
}

EXPORT uint32_t i2c0_error_count(void)
{
    return (error_count);
}
