/*
 * adc_sampler.c
 *
 * Group AAI18 -- RP2040 ADC round-robin sampler.
 *
 * Written against the registers directly because the template's BSP has no
 * ADC support and the Pico SDK's hardware/adc.h is not on the application
 * include path.  See drivers/rp2040_regs.h for why.
 *
 * APIs used: out_w, in_w, set_w, clr_w (template register helpers)
 */

#include "adc_sampler.h"
#include "rp2040_regs.h"

/* ---------------------------------------------------------------------
 * Private data
 * --------------------------------------------------------------------- */

/* Latest sample per channel.  Single writer (adc_sampler_poll). */
static adc_sample_t latest[ADC_CH_COUNT];
static bool         b_have_sample[ADC_CH_COUNT];

/* Barcode history ring.  Single writer, multiple readers. */
static adc_sample_t ring[ADC_RING_LEN];
static volatile uint32_t ring_write_index = 0u;

static uint32_t overrun_count = 0u;
static bool     b_initialised = false;

/* ---------------------------------------------------------------------
 * Private functions
 * --------------------------------------------------------------------- */

/*
 * Put one GPIO into analogue mode: disable both the digital input buffer
 * and the pulls, which is what the datasheet requires before using the pin
 * as an ADC input.  PADS_BANK0 control register for GPIO n sits at
 * PADS_BANK0_BASE + 4 + 4*n.
 */
static void adc_pin_to_analogue(uint32_t gpio)
{
    const uint32_t pads_base = 0x4001C000u;
    uint32_t       pad_reg   = pads_base + 0x04u + (4u * gpio);

    /* Clear IE (bit 6) and PUE/PDE (bits 3 and 2); set OD (bit 7). */
    clr_w(pad_reg, (1u << 6u) | (1u << 3u) | (1u << 2u));
    set_w(pad_reg, (1u << 7u));
}

/*
 * Push one FIFO entry into the per-channel latest value and, when it is
 * the barcode channel, into the history ring.
 *
 * The round-robin walks ADC0 -> ADC1 -> ADC2 in order, so the channel of
 * each FIFO entry is tracked by a rotating counter rather than read back
 * from the hardware: the FIFO entry itself does not carry a channel tag.
 * A FIFO overrun therefore loses channel alignment, which is exactly why
 * an overrun is counted and published rather than ignored.
 */
static void store_sample(uint8_t channel, uint16_t value, uint32_t now_us)
{
    uint32_t index;

    if (channel >= ADC_CH_COUNT)
    {
        return;
    }

    latest[channel].value        = value;
    latest[channel].timestamp_us = now_us;
    b_have_sample[channel]       = true;

    if (ADC_CH_BARCODE == channel)
    {
        index = ring_write_index % ADC_RING_LEN;
        ring[index].value        = value;
        ring[index].timestamp_us = now_us;

        /* Advance the index LAST, so a reader never sees a half-written
           entry as if it were current. */
        ring_write_index = ring_write_index + 1u;
    }
}

/* ---------------------------------------------------------------------
 * Public functions
 * --------------------------------------------------------------------- */

EXPORT ER adc_sampler_init(void)
{
    uint32_t i;

    if (b_initialised)
    {
        return (E_OK);
    }

    for (i = 0u; i < ADC_CH_COUNT; i++)
    {
        latest[i].value        = 0u;
        latest[i].timestamp_us = 0u;
        b_have_sample[i]       = false;
    }

    /* Release the ADC from reset and wait for it to come up. */
    clr_w(RESETS_RESET, RESETS_RESET_ADC);
    while (0u == (in_w(RESETS_RESET_DONE) & RESETS_RESET_ADC))
    {
        /* Busy wait: this runs once, at init, before any task is started. */
    }

    adc_pin_to_analogue(PIN_IR_LINE_L);
    adc_pin_to_analogue(PIN_IR_LINE_C);
    adc_pin_to_analogue(PIN_IR_BARCODE);

    /* Enable the ADC, no temperature sensor. */
    out_w(ADC_CS, ADC_CS_EN);
    while (0u == (in_w(ADC_CS) & ADC_CS_READY))
    {
        /* Wait for the first calibration to settle. */
    }

    /*
     * Clock divider.  The ADC runs from a 48 MHz clock and takes 96 cycles
     * per conversion, giving 500 ksps at DIV = 0.  We do not need anything
     * like that rate: three channels at roughly 10 kHz each is far more
     * than the 1 ms barcode tick can consume, and a slower rate keeps the
     * FIFO from overrunning between polls.  DIV is in 8.8 fixed point.
     *
     * 48e6 / (1 + 1500) ~= 32 ksps total, ~10.6 ksps per channel.
     */
    out_w(ADC_DIV, (1500u << 8u));

    /* FIFO: enabled, no DMA request, full 12-bit results (no shift). */
    out_w(ADC_FCS, ADC_FCS_EN);

    /*
     * Round-robin across ADC0, ADC1 and ADC2, starting at ADC0, then start
     * free-running conversion.  RROBIN is a bitmask of the channels to
     * include; AINSEL picks where the sequence begins.
     */
    out_w(ADC_CS, ADC_CS_EN
                | (0u << ADC_CS_AINSEL_SHIFT)
                | (0x07u << ADC_CS_RROBIN_SHIFT)
                | ADC_CS_START_MANY);

    ring_write_index = 0u;
    overrun_count    = 0u;
    b_initialised    = true;

    return (E_OK);
}

EXPORT uint8_t adc_sampler_poll(void)
{
    static uint8_t next_channel = 0u;
    uint32_t       fcs;
    uint32_t       entry;
    uint32_t       now_us;
    uint8_t        drained = 0u;

    if (!b_initialised)
    {
        return (0u);
    }

    fcs = in_w(ADC_FCS);

    /*
     * An overrun means the FIFO wrapped between polls, so the channel
     * rotation is no longer trustworthy.  Count it, clear the sticky bit,
     * drop the whole FIFO and resynchronise the rotation rather than
     * attributing samples to the wrong channel.
     */
    if (0u != (fcs & ADC_FCS_OVER))
    {
        overrun_count = overrun_count + 1u;
        set_w(ADC_FCS, ADC_FCS_OVER);

        while (0u == (in_w(ADC_FCS) & ADC_FCS_EMPTY))
        {
            (void)in_w(ADC_FIFO);
        }

        /* The next conversion the hardware completes is the one AINSEL
           currently points at. */
        next_channel = (uint8_t)((in_w(ADC_CS) & ADC_CS_AINSEL_MASK)
                                 >> ADC_CS_AINSEL_SHIFT);
        return (0u);
    }

    now_us = RP2040_NOW_US();

    while ((0u == (in_w(ADC_FCS) & ADC_FCS_EMPTY)) && (drained < 32u))
    {
        entry = in_w(ADC_FIFO);

        if (0u == (entry & ADC_FIFO_ERR))
        {
            store_sample(next_channel,
                         (uint16_t)(entry & ADC_FIFO_VAL_MASK),
                         now_us);
        }

        next_channel = (uint8_t)((next_channel + 1u) % ADC_CH_COUNT);
        drained      = (uint8_t)(drained + 1u);
    }

    return (drained);
}

EXPORT bool adc_sampler_read(uint8_t channel, adc_sample_t *p_out)
{
    bool b_ok = false;

    if ((channel < ADC_CH_COUNT) && (NULL != p_out) && b_have_sample[channel])
    {
        /* Copy value then timestamp.  Both are single words, so neither
           can tear on its own; the pair may be one sample out of date,
           which the consumer's staleness check already tolerates. */
        p_out->value        = latest[channel].value;
        p_out->timestamp_us = latest[channel].timestamp_us;
        b_ok = true;
    }

    return (b_ok);
}

EXPORT uint8_t adc_sampler_since(uint32_t after_us, adc_sample_t *p_out,
                                 uint8_t max_out)
{
    uint32_t write_snapshot;
    uint32_t scan;
    uint32_t oldest;
    uint8_t  count = 0u;

    if ((NULL == p_out) || (0u == max_out))
    {
        return (0u);
    }

    write_snapshot = ring_write_index;

    /* Walk only entries still present in the ring. */
    if (write_snapshot > ADC_RING_LEN)
    {
        oldest = write_snapshot - ADC_RING_LEN;
    }
    else
    {
        oldest = 0u;
    }

    for (scan = oldest; scan < write_snapshot; scan++)
    {
        adc_sample_t *p_entry = &ring[scan % ADC_RING_LEN];

        /* Unsigned subtraction handles the 71-minute timer wrap correctly:
           a sample newer than after_us gives a small positive difference. */
        if ((uint32_t)(p_entry->timestamp_us - after_us) <= 0x7FFFFFFFu)
        {
            if (p_entry->timestamp_us != after_us)
            {
                p_out[count] = *p_entry;
                count        = (uint8_t)(count + 1u);

                if (count >= max_out)
                {
                    break;
                }
            }
        }
    }

    return (count);
}

EXPORT uint32_t adc_sampler_overruns(void)
{
    return (overrun_count);
}

EXPORT void adc_sampler_selftest(void)
{
    adc_sample_t sample;
    uint8_t      ch;

    tm_printf((UB*)"[ADC] CS=%08x FCS=%08x DIV=%08x\n",
              in_w(ADC_CS), in_w(ADC_FCS), in_w(ADC_DIV));
    tm_printf((UB*)"[ADC] overruns=%d\n", (INT)overrun_count);

    for (ch = 0u; ch < ADC_CH_COUNT; ch++)
    {
        if (adc_sampler_read(ch, &sample))
        {
            tm_printf((UB*)"[ADC] ch%d = %d (t=%d us)\n",
                      (INT)ch, (INT)sample.value, (INT)sample.timestamp_us);
        }
        else
        {
            tm_printf((UB*)"[ADC] ch%d = no sample yet\n", (INT)ch);
        }
    }
}
