/*
 * app_main.c
 *
 * Group AAI18 -- entry point.
 *
 * usermain() runs inside the kernel's initial task at priority 1.  It
 * works in two phases so that every kernel object exists before any task
 * can use one:
 *   phase 1  subsystemN_init()   create kernel objects, bring up hardware
 *   phase 2  subsystemN_start()  create and start tasks
 * and then sleeps forever.  Returning would shut the system down.
 *
 * CORE ASSIGNMENT
 * ---------------
 * Every driving task is pinned to core 0 and Telemetry to core 1.  That
 * is the strongest available form of the NFR6 guarantee: network work
 * physically cannot steal cycles from the control loop.
 *
 * INIT ORDER MATTERS
 * ------------------
 * Subsystem 5 is initialised FIRST despite its number, because it creates
 * the shared fault bitmask (fault_init) and the event flag that every
 * other subsystem posts to.  Subsystem 2 then creates the IO_BANK0
 * dispatcher that subsystem 5's ECHO timing depends on.  The order below
 * is deliberate; changing it will produce objects referenced before they
 * exist.
 */

#include "app.h"
#include "fault.h"
#include "msg_defs.h"
#include "subsystem1/subsystem1.h"
#include "subsystem2/subsystem2.h"
#include "subsystem3/subsystem3.h"
#include "subsystem4/subsystem4.h"
#include "subsystem5/subsystem5.h"

EXPORT ID app_start_task(FP entry, PRI pri, UW prc, const char *name)
{
    T_CTSK ctsk = {0};
    ID     tid;
    ER     er;

    ctsk.task    = entry;
    ctsk.itskpri = pri;
    ctsk.stksz   = TASK_STACK_SIZE;
    ctsk.tskatr  = TA_HLNG | TA_RNG3;

#if TK_SUPPORT_SMP
    if (prc != 0)
    {
        ctsk.tskatr |= TA_ASSPRC;
        ctsk.assprc  = prc;
    }
#else
    (void)prc;
#endif

    tid = tk_cre_tsk(&ctsk);
    if (tid < E_OK)
    {
        CHECK(tid, name);
        return (tid);
    }

    er = tk_sta_tsk(tid, 0);
    CHECK(er, name);

    return (tid);
}

EXPORT uint32_t app_now_ms(void)
{
    SYSTIM tim;

    /*
     * tk_get_tim gives the system time in milliseconds as a 64-bit value
     * split across two fields.  The low 32 bits give 49 days of range,
     * which is far more than one run, and the staleness checks that use
     * this all work on unsigned differences, so a wrap is handled.
     */
    if (tk_get_tim(&tim) < E_OK)
    {
        return (0u);
    }

    return ((uint32_t)tim.ltime);
}

EXPORT INT usermain(void)
{
    T_RVER ver;

    tk_ref_ver(&ver);
    tm_printf((UB*)"\n=== INF2004 Group AAI18 -- Autonomous Robot Car ===\n");
    tm_printf((UB*)"micro T-Kernel spec 0x%04x product 0x%04x\n",
              ver.spver, ver.prver);
#if TK_SUPPORT_SMP
    tm_printf((UB*)"dual-core build, usermain on core %d\n",
              tk_get_prc() - 1);
#else
    tm_printf((UB*)"single-core build\n");
#endif
    tm_printf((UB*)"message schema version %d\n", (INT)MSG_SCHEMA_VERSION);

    /* ---- phase 1: kernel objects and hardware ---- */
    /* S5 first: it owns the fault bitmask and the event flag. */
    CHECK(subsystem5_init(), "subsystem5_init");
    /* S2 next: it creates the shared IO_BANK0 dispatcher. */
    CHECK(subsystem2_init(), "subsystem2_init");
    CHECK(subsystem1_init(), "subsystem1_init");
    CHECK(subsystem3_init(), "subsystem3_init");
    CHECK(subsystem4_init(), "subsystem4_init");

    /* ---- phase 2: tasks ---- */
    CHECK(subsystem2_start(), "subsystem2_start");
    CHECK(subsystem3_start(), "subsystem3_start");
    CHECK(subsystem4_start(), "subsystem4_start");
    CHECK(subsystem5_start(), "subsystem5_start");
    CHECK(subsystem1_start(), "subsystem1_start");

    tm_printf((UB*)"all subsystems started\n\n");

#if APP_TEST
    tm_printf((UB*)"[TEST] === test run start ===\n");
    subsystem1_test();
    subsystem2_test();
    subsystem3_test();
    subsystem4_test();
    subsystem5_test();
    tm_printf((UB*)"[TEST] === test run end ===\n");
#endif

    tk_slp_tsk(TMO_FEVR);

    return (0);
}
