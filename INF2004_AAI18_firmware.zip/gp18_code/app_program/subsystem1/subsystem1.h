/*
 * subsystem1.h
 *
 * Subsystem 1 -- WiFi, MQTT and telemetry.  Buddy 1 (Levl Lim), 2501118.
 *
 * Implements Statechart 1 of Design Review V2 section 6.1.
 *
 * TWO RULES THIS SUBSYSTEM EXISTS TO HONOUR
 * -----------------------------------------
 * 1. NFR6: a WiFi or MQTT failure must NEVER block, delay or stop any
 *    driving task.  This task runs at the lowest priority and every
 *    network call it makes is outside the telemetry mutex.
 *
 * 2. The telemetry snapshot is written by Motion Control (Highest) and
 *    read here (Lowest), so without priority inheritance this task can
 *    block the one task that must never be blocked.  The mutex is created
 *    with TA_INHERIT and the critical section is a struct copy and
 *    nothing else -- the binary encoding happens after the mutex is
 *    released (design rule R6).
 *
 * MEASUREMENT STILL OWED: Motion Control's worst-case blocking time behind
 * this task has never been measured.  s1_max_hold_us() exists so the first
 * bench session can produce that number.
 */

#ifndef SUBSYSTEM1_H
#define SUBSYSTEM1_H

#include "../app.h"
#include "../msg_defs.h"
#include <stdint.h>
#include <stdbool.h>

/* MQTT topics.  Design Review V2 section 6.1 -- these were undefined at
   Week 6 and are fixed here. */
#define S1_TOPIC_STATE      "car18/tele/state"
#define S1_TOPIC_HEARTBEAT  "car18/tele/hb"
#define S1_TOPIC_FAULT      "car18/tele/fault"
#define S1_TOPIC_CMD        "car18/cmd"

#define S1_HEARTBEAT_MS     (1000u)
#define S1_RECONNECT_MS     (2000u)
#define S1_RECONNECT_TARGET_MS (10000u)  /* NFR6 */

typedef enum
{
    S1_WIFI_INIT         = 0,
    S1_WIFI_CONNECTING   = 1,
    S1_MQTT_CONNECTING   = 2,
    S1_CONNECTED         = 3,
    S1_RECONNECTING      = 4
} s1_conn_state_t;

/* Remote command codes carried on S1_TOPIC_CMD. */
#define S1_CMD_START        (0x01u)
#define S1_CMD_STOP         (0x02u)
#define S1_CMD_RESET        (0x03u)

/*
 * The shared snapshot.  Each subsystem writes ONLY its own fields, under
 * the mutex.  Telemetry copies the whole struct under the mutex and then
 * encodes outside it.
 */
typedef struct
{
    uint8_t  veh_state;
    uint8_t  line_state;
    int8_t   line_error;
    bool     b_line_valid;
    uint8_t  speed_pct;
    uint8_t  hump_mm;
    bool     b_hump_sat;
    int8_t   tilt_deg;
    uint8_t  obst_distance_cm;
    uint16_t encoder_delta;
} s1_snapshot_t;

/* Update the caller's own fields.  Takes the mutex for a struct copy. */
void s1_publish_fields(const s1_snapshot_t *p_fields);

s1_conn_state_t s1_get_conn_state(void);

/* Longest time the telemetry mutex has been held, in microseconds.  This
   bounds Motion Control's worst-case blocking and is the figure test T1
   must report. */
uint32_t s1_max_hold_us(void);
void     s1_reset_stats(void);

/*
 * Accept an inbound remote command.  Returns false if the command is
 * stale or a duplicate.
 *
 * Stale/duplicate rejection was undefined at Week 6 and is fixed here: a
 * command is accepted only if its sequence number is strictly greater
 * than the last accepted one, modulo wrap.  Without this, a retained or
 * replayed MQTT message could restart a car that had been stopped.
 */
bool s1_accept_command(uint8_t seq, uint8_t command);

IMPORT ID   mtx_telemetry;
IMPORT ID   tid_telemetry;
IMPORT void telemetry_task(INT stacd, void *exinf);

#endif /* SUBSYSTEM1_H */
