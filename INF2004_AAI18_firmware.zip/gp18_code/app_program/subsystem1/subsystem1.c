/*
 * subsystem1.c
 *
 * Subsystem 1 -- telemetry: creates the snapshot mutex and starts the
 * telemetry task.
 */

#include "subsystem1.h"

EXPORT ER subsystem1_init(void)
{
    T_CMTX cmtx = {0};

    /*
     * TA_INHERIT is the important attribute here, not an optional extra.
     *
     * Motion Control (Highest) writes this snapshot and Telemetry
     * (Lowest) reads it.  Without priority inheritance, Telemetry holding
     * the mutex while a Medium-priority task runs would block Motion
     * Control for an unbounded time -- classic priority inversion, and
     * the one task in this system that must never be blocked.
     *
     * TA_INHERIT lifts Telemetry to the waiter's priority for as long as
     * it holds the mutex, which bounds the blocking to the length of the
     * critical section.  That is why the critical section is a struct
     * copy and nothing more.
     */
    cmtx.mtxatr = TA_TFIFO | TA_INHERIT;
    cmtx.ceilpri = PRI_MOTION_CONTROL;

    mtx_telemetry = tk_cre_mtx(&cmtx);

    return ((mtx_telemetry < E_OK) ? (ER)mtx_telemetry : E_OK);
}

EXPORT ER subsystem1_start(void)
{
    /*
     * Pinned to core 1 (TP_PRC2).  Every driving task runs on core 0, so
     * network work cannot steal cycles from them even in the worst case.
     * This is the strongest form of the NFR6 guarantee available on this
     * hardware.
     */
    tid_telemetry = app_start_task(telemetry_task, PRI_TELEMETRY,
                                   TP_PRC2, "telemetry_task");

    return ((tid_telemetry < E_OK) ? (ER)tid_telemetry : E_OK);
}
