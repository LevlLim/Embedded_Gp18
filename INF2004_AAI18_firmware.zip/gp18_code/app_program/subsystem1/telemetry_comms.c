/*
 * telemetry_comms.c
 *
 * Subsystem 1 -- telemetry task, snapshot mutex and remote commands.
 *
 * The MQTT transport itself lives in the template's
 * lib/liblwip/sysdepend/pico_rp2040/mqtt_utk.c and runs on the radio's
 * own service task.  This file prepares the binary frames and hands them
 * over; it never blocks a driving task waiting for the network.
 */

#include "subsystem1.h"
#include "../fault.h"
#include "../drivers/rp2040_regs.h"
#include "../subsystem2/subsystem2.h"
#include "../subsystem3/subsystem3.h"
#include "../subsystem4/subsystem4.h"
#include "../subsystem5/subsystem5.h"

EXPORT ID mtx_telemetry = 0;
EXPORT ID tid_telemetry = 0;

/* ---------------------------------------------------------------------
 * Private state
 * --------------------------------------------------------------------- */

static s1_snapshot_t   snapshot;
static s1_conn_state_t conn_state = S1_WIFI_INIT;
static uint8_t         frame_seq  = 0u;
static uint32_t        max_hold_us = 0u;
static uint8_t         last_cmd_seq = 0u;
static bool            b_have_cmd_seq = false;

/* ---------------------------------------------------------------------
 * Private
 * --------------------------------------------------------------------- */

/*
 * Copy the snapshot out under the mutex and nothing else.  Encoding
 * happens in the caller, AFTER this returns, so the mutex is never held
 * across the expensive part (design rule R6).
 */
static bool take_snapshot(s1_snapshot_t *p_copy)
{
    uint32_t t_in;
    uint32_t held;
    bool     b_ok = false;

    /*
     * TMO_POL, not TMO_FEVR.  If the mutex is busy this cycle, skipping
     * one telemetry frame is harmless; waiting could add latency to a
     * cycle that matters.  Telemetry never waits on anything that a
     * driving task holds.
     */
    if (tk_loc_mtx(mtx_telemetry, TMO_POL) >= E_OK)
    {
        t_in   = RP2040_NOW_US();
        *p_copy = snapshot;
        held   = RP2040_NOW_US() - t_in;

        (void)tk_unl_mtx(mtx_telemetry);

        if (held > max_hold_us)
        {
            max_hold_us = held;
        }

        b_ok = true;
    }

    return (b_ok);
}

/*
 * Gather the fields this task can read directly from the other
 * subsystems' accessors, rather than requiring every subsystem to push.
 * Cheaper than a write from each task, and it keeps the mutex hold short.
 */
static void gather(s1_snapshot_t *p_out)
{
    msg_obstacle_t obstacle;

    p_out->veh_state  = s5_get_encoded_state();
    p_out->line_state = (uint8_t)s3_get_line_state();
    p_out->hump_mm    = s4_get_run_max_peak_mm();
    p_out->b_hump_sat = s4_peak_saturated();
    p_out->tilt_deg   = s4_get_tilt_deg();
    p_out->encoder_delta = s2_take_encoder_delta();

    if (s5_get_obstacle(&obstacle))
    {
        p_out->obst_distance_cm = obstacle.distance_cm;
    }
    else
    {
        p_out->obst_distance_cm = 0u;
    }
}

/*
 * Hand a frame to the MQTT layer.  Declared weak-ish via a stub so the
 * firmware links and runs with WIFI=none during bring-up: telemetry then
 * prints to the console instead, which is what the early bench sessions
 * will use anyway.
 */
static void publish(const char *p_topic, const uint8_t *p_payload,
                    uint8_t len)
{
#if defined(APP_MQTT) && (APP_MQTT == 1)
    extern void mqtt_utk_publish(const char *topic, const uint8_t *data,
                                 uint16_t len);
    mqtt_utk_publish(p_topic, p_payload, (uint16_t)len);
#else
    uint8_t i;

    tm_printf((UB*)"[TELE] %s (%d B):", p_topic, (INT)len);
    for (i = 0u; i < len; i++)
    {
        tm_printf((UB*)" %02x", (INT)p_payload[i]);
    }
    tm_printf((UB*)"\n");
#endif
}

/* ---------------------------------------------------------------------
 * Public
 * --------------------------------------------------------------------- */

EXPORT void s1_publish_fields(const s1_snapshot_t *p_fields)
{
    uint32_t t_in;
    uint32_t held;

    if (NULL == p_fields)
    {
        return;
    }

    if (tk_loc_mtx(mtx_telemetry, TMO_POL) >= E_OK)
    {
        t_in     = RP2040_NOW_US();
        snapshot = *p_fields;
        held     = RP2040_NOW_US() - t_in;

        (void)tk_unl_mtx(mtx_telemetry);

        if (held > max_hold_us)
        {
            max_hold_us = held;
        }
    }
}

EXPORT bool s1_accept_command(uint8_t seq, uint8_t command)
{
    bool b_accept = false;

    /*
     * Monotonic sequence check.  The first command after boot is always
     * accepted; after that, a command is accepted only if its sequence
     * number has advanced.  The subtraction is modulo 256, so wrap is
     * handled: a difference in 1..127 counts as newer.
     */
    if (!b_have_cmd_seq)
    {
        b_accept       = true;
        b_have_cmd_seq = true;
    }
    else
    {
        uint8_t delta = (uint8_t)(seq - last_cmd_seq);

        if ((delta > 0u) && (delta < 128u))
        {
            b_accept = true;
        }
    }

    if (b_accept)
    {
        last_cmd_seq = seq;

        switch (command)
        {
            case S1_CMD_START:
                s5_post_event(S5_EVT_REMOTE_START);
                break;

            case S1_CMD_STOP:
                /*
                 * STOP sets the fault bit DIRECTLY as well as notifying
                 * the Controller, so Motion Control brakes without
                 * waiting for the Controller to be scheduled (FR10).
                 */
                fault_set(FAULT_REMOTE_STOP);
                s5_post_event(S5_EVT_REMOTE_STOP);
                break;

            case S1_CMD_RESET:
                s5_post_event(S5_EVT_RESET);
                break;

            default:
                b_accept = false;
                break;
        }
    }
    else
    {
        tm_printf((UB*)"[S1] rejected stale command seq=%d\n", (INT)seq);
    }

    return (b_accept);
}

EXPORT void telemetry_task(INT stacd, void *exinf)
{
    s1_snapshot_t   local;
    msg_telemetry_t frame;
    uint8_t         buf[MSG_LEN_TELEMETRY];
    uint8_t         len;
    uint32_t        last_heartbeat_ms = 0u;
    uint16_t        last_fault_mask   = 0u;
    uint16_t        faults;

    (void)stacd;
    (void)exinf;

    conn_state = S1_CONNECTED;     /* the radio task owns the real state */

    for (;;)
    {
        gather(&snapshot);

        if (take_snapshot(&local))
        {
            /* ---- encode OUTSIDE the mutex ---- */
            frame.seq              = frame_seq;
            frame.veh_state        = local.veh_state;
            frame.line_state       = local.line_state;
            frame.line_error       = local.line_error;
            frame.b_line_valid     = local.b_line_valid;
            frame.speed_pct        = local.speed_pct;
            frame.hump_mm          = local.hump_mm;
            frame.b_hump_sat       = local.b_hump_sat;
            frame.tilt_deg         = local.tilt_deg;
            frame.obst_distance_cm = local.obst_distance_cm;
            frame.encoder_delta    = local.encoder_delta;
            frame.fault_mask       = fault_get();
            frame.wifi_state       = (uint8_t)conn_state;

            frame_seq = (uint8_t)(frame_seq + 1u);

            len = msg_pack_telemetry(&frame, buf, sizeof(buf));
            if (0u != len)
            {
                publish(S1_TOPIC_STATE, buf, len);
            }
        }

        /* ---- fault topic, published on CHANGE ---- */
        faults = fault_get();
        if (faults != last_fault_mask)
        {
            uint8_t fault_buf[2];

            fault_buf[0] = (uint8_t)(faults & 0xFFu);
            fault_buf[1] = (uint8_t)((faults >> 8u) & 0xFFu);

            publish(S1_TOPIC_FAULT, fault_buf, 2u);
            last_fault_mask = faults;
        }

        /* ---- 1 s heartbeat (NFR6) ---- */
        if ((app_now_ms() - last_heartbeat_ms) >= S1_HEARTBEAT_MS)
        {
            uint8_t beat = frame_seq;

            publish(S1_TOPIC_HEARTBEAT, &beat, 1u);
            last_heartbeat_ms = app_now_ms();
        }

        (void)tk_dly_tsk(PERIOD_TELEMETRY_MS);
    }
}

EXPORT s1_conn_state_t s1_get_conn_state(void) { return (conn_state); }
EXPORT uint32_t s1_max_hold_us(void)           { return (max_hold_us); }
EXPORT void s1_reset_stats(void)               { max_hold_us = 0u; }
