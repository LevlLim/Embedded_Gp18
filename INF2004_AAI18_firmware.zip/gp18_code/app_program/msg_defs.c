/*
 * msg_defs.c
 *
 * Group AAI18 -- minimum-bit encode and decode helpers.
 *
 * Implements Change Requirement 1 / NFR12.  Every function here is pure:
 * it touches no hardware and no kernel object, so it can be unit tested on
 * a host PC.  That is deliberate -- testing/host/ runs these same functions
 * to produce the round-trip evidence required by section 7.5 of the design
 * review, without needing the robot.
 *
 * Signed fields are stored as two's complement in the stated number of bits
 * and sign-extended on the way out.  Bitwise operators are applied only to
 * unsigned containers (Barr-C 5.3b).
 */

#include "msg_defs.h"

/* ---------------------------------------------------------------------
 * Private helpers
 * --------------------------------------------------------------------- */

/*
 * Sign-extend the low 'bits' of an unsigned container into a signed value.
 */
static int32_t sign_extend(uint32_t raw, uint8_t bits)
{
    uint32_t sign_bit = (uint32_t)1u << (bits - 1u);
    int32_t  result;

    if (0u != (raw & sign_bit))
    {
        /* Set every bit above the field so the value becomes negative. */
        result = (int32_t)(raw | ~((sign_bit << 1u) - 1u));
    }
    else
    {
        result = (int32_t)raw;
    }

    return (result);
}

/*
 * Mask a signed value into the low 'bits' of an unsigned container.
 */
static uint32_t to_field(int32_t value, uint8_t bits)
{
    uint32_t mask = ((uint32_t)1u << bits) - 1u;

    return ((uint32_t)value & mask);
}

/* ---------------------------------------------------------------------
 * Public: saturating encoders (design rule R5)
 * --------------------------------------------------------------------- */

uint16_t msg_sat_u16(uint32_t value, uint16_t limit, bool *p_saturated)
{
    uint16_t result;

    if (value > (uint32_t)limit)
    {
        result = limit;
        if (NULL != p_saturated)
        {
            *p_saturated = true;
        }
    }
    else
    {
        result = (uint16_t)value;
    }

    return (result);
}

int8_t msg_sat_i8(int32_t value, int8_t limit, bool *p_saturated)
{
    int8_t result;

    if (value > (int32_t)limit)
    {
        result = limit;
        if (NULL != p_saturated)
        {
            *p_saturated = true;
        }
    }
    else if (value < -(int32_t)limit)
    {
        result = (int8_t)(-limit);
        if (NULL != p_saturated)
        {
            *p_saturated = true;
        }
    }
    else
    {
        result = (int8_t)value;
    }

    return (result);
}

/* ---------------------------------------------------------------------
 * Public: vehicle state (3-bit parent + 2-bit substate)
 * --------------------------------------------------------------------- */

uint8_t msg_encode_veh_state(uint8_t parent, uint8_t substate)
{
    return (uint8_t)(((parent & 0x07u) << 2u) | (substate & 0x03u));
}

void msg_decode_veh_state(uint8_t encoded, uint8_t *p_parent,
                          uint8_t *p_substate)
{
    if (NULL != p_parent)
    {
        *p_parent = (uint8_t)((encoded >> 2u) & 0x07u);
    }
    if (NULL != p_substate)
    {
        *p_substate = (uint8_t)(encoded & 0x03u);
    }
}

/* ---------------------------------------------------------------------
 * Public: motion command, 2 bytes (was 8 unpacked)
 *   bits  0..2   command type
 *   bits  3..12  argument (mm or degrees)
 *   bits 13..15  sequence number
 * --------------------------------------------------------------------- */

uint8_t msg_pack_motion_cmd(const msg_motion_cmd_t *p_cmd,
                            uint8_t *p_buf, uint8_t buf_len)
{
    uint32_t word;
    uint16_t arg;
    uint8_t  written = 0u;

    if ((NULL != p_cmd) && (NULL != p_buf) && (buf_len >= MSG_LEN_MOTION_CMD))
    {
        arg = msg_sat_u16((uint32_t)p_cmd->arg, MSG_MAX_CMD_ARG, NULL);

        word  = ((uint32_t)p_cmd->type & 0x07u);
        word |= ((uint32_t)arg & 0x03FFu) << 3u;
        word |= ((uint32_t)p_cmd->seq & 0x07u) << 13u;

        /* Little-endian, byte by byte (rule R3): never cast a struct over
           the buffer, because the Cortex-M0+ faults on unaligned access. */
        p_buf[0] = (uint8_t)(word & 0xFFu);
        p_buf[1] = (uint8_t)((word >> 8u) & 0xFFu);
        written  = MSG_LEN_MOTION_CMD;
    }

    return (written);
}

bool msg_unpack_motion_cmd(const uint8_t *p_buf, uint8_t buf_len,
                           msg_motion_cmd_t *p_cmd)
{
    uint32_t word;
    bool     b_ok = false;

    if ((NULL != p_buf) && (NULL != p_cmd) && (buf_len >= MSG_LEN_MOTION_CMD))
    {
        word = (uint32_t)p_buf[0] | ((uint32_t)p_buf[1] << 8u);

        p_cmd->type = (msg_cmd_type_t)(word & 0x07u);
        p_cmd->arg  = (uint16_t)((word >> 3u) & 0x03FFu);
        p_cmd->seq  = (uint8_t)((word >> 13u) & 0x07u);
        b_ok = true;
    }

    return (b_ok);
}

/* ---------------------------------------------------------------------
 * Public: barcode command, 1 byte (was 4 unpacked)
 *   bits 0..2  command
 *   bits 3..5  confidence
 *   bits 6..7  sequence
 * --------------------------------------------------------------------- */

uint8_t msg_pack_barcode(const msg_barcode_t *p_bc,
                         uint8_t *p_buf, uint8_t buf_len)
{
    uint8_t written = 0u;

    if ((NULL != p_bc) && (NULL != p_buf) && (buf_len >= MSG_LEN_BARCODE))
    {
        p_buf[0] = (uint8_t)(((uint32_t)p_bc->cmd & 0x07u)
                           | (((uint32_t)p_bc->confidence & 0x07u) << 3u)
                           | (((uint32_t)p_bc->seq & 0x03u) << 6u));
        written = MSG_LEN_BARCODE;
    }

    return (written);
}

bool msg_unpack_barcode(const uint8_t *p_buf, uint8_t buf_len,
                        msg_barcode_t *p_bc)
{
    bool b_ok = false;

    if ((NULL != p_buf) && (NULL != p_bc) && (buf_len >= MSG_LEN_BARCODE))
    {
        p_bc->cmd        = (msg_barcode_cmd_t)(p_buf[0] & 0x07u);
        p_bc->confidence = (uint8_t)((p_buf[0] >> 3u) & 0x07u);
        p_bc->seq        = (uint8_t)((p_buf[0] >> 6u) & 0x03u);
        b_ok = true;
    }

    return (b_ok);
}

/* ---------------------------------------------------------------------
 * Public: obstacle profile, 5 bytes (was 16 unpacked)
 *   bits  0..7   distance    (8)
 *   bits  8..13  width       (6)
 *   bits 14..20  bearing     (7, signed)
 *   bits 21..25  clear left  (5)
 *   bits 26..30  clear right (5)
 *   bits 31..32  side        (2)
 *   bit  33      saturated flag
 * --------------------------------------------------------------------- */

uint8_t msg_pack_obstacle(const msg_obstacle_t *p_obs,
                          uint8_t *p_buf, uint8_t buf_len)
{
    uint64_t word;
    uint8_t  i;
    uint8_t  written = 0u;

    if ((NULL != p_obs) && (NULL != p_buf) && (buf_len >= MSG_LEN_OBSTACLE))
    {
        word  = (uint64_t)(p_obs->distance_cm & 0xFFu);
        word |= (uint64_t)(p_obs->width_cm & 0x3Fu) << 8u;
        word |= (uint64_t)to_field((int32_t)p_obs->bearing_deg,
                                   MSG_BITS_OBST_BEARING) << 14u;
        word |= (uint64_t)(p_obs->clear_left_cm & 0x1Fu) << 21u;
        word |= (uint64_t)(p_obs->clear_right_cm & 0x1Fu) << 26u;
        word |= (uint64_t)((uint32_t)p_obs->side & 0x03u) << 31u;
        word |= (uint64_t)(p_obs->b_saturated ? 1u : 0u) << 33u;

        for (i = 0u; i < MSG_LEN_OBSTACLE; i++)
        {
            p_buf[i] = (uint8_t)((word >> (8u * i)) & 0xFFu);
        }
        written = MSG_LEN_OBSTACLE;
    }

    return (written);
}

bool msg_unpack_obstacle(const uint8_t *p_buf, uint8_t buf_len,
                         msg_obstacle_t *p_obs)
{
    uint64_t word = 0u;
    uint8_t  i;
    bool     b_ok = false;

    if ((NULL != p_buf) && (NULL != p_obs) && (buf_len >= MSG_LEN_OBSTACLE))
    {
        for (i = 0u; i < MSG_LEN_OBSTACLE; i++)
        {
            word |= (uint64_t)p_buf[i] << (8u * i);
        }

        p_obs->distance_cm    = (uint8_t)(word & 0xFFu);
        p_obs->width_cm       = (uint8_t)((word >> 8u) & 0x3Fu);
        p_obs->bearing_deg    = (int8_t)sign_extend(
                                    (uint32_t)((word >> 14u) & 0x7Fu),
                                    MSG_BITS_OBST_BEARING);
        p_obs->clear_left_cm  = (uint8_t)((word >> 21u) & 0x1Fu);
        p_obs->clear_right_cm = (uint8_t)((word >> 26u) & 0x1Fu);
        p_obs->side           = (msg_side_t)((word >> 31u) & 0x03u);
        p_obs->b_saturated    = (0u != ((word >> 33u) & 0x01u));
        b_ok = true;
    }

    return (b_ok);
}

/* ---------------------------------------------------------------------
 * Public: telemetry frame, 12 bytes.
 *
 * Byte 0 is the schema version and byte 1 the frame sequence number, so a
 * subscriber can detect both a layout mismatch and a dropped frame.  The
 * equivalent text/JSON payload is roughly 120 bytes; the ten-fold
 * reduction is the figure reported in the Week 13 comparison.
 *
 *   byte 0      schema version
 *   byte 1      frame sequence
 *   byte 2      veh_state (5) | line_state low 3
 *   byte 3      line_error (7, signed) | line_valid (1)
 *   byte 4      speed_pct (7) | hump_sat (1)
 *   byte 5      hump_mm (7) | spare (1)
 *   byte 6      tilt_deg (7, signed) | spare (1)
 *   byte 7      obstacle distance (8)
 *   bytes 8..9  fault mask (10 used) | wifi_state (3)
 *   bytes 10..11 encoder delta (16)
 * --------------------------------------------------------------------- */

uint8_t msg_pack_telemetry(const msg_telemetry_t *p_tel,
                           uint8_t *p_buf, uint8_t buf_len)
{
    uint16_t fault_word;
    uint8_t  written = 0u;

    if ((NULL != p_tel) && (NULL != p_buf) && (buf_len >= MSG_LEN_TELEMETRY))
    {
        p_buf[0] = MSG_SCHEMA_VERSION;
        p_buf[1] = p_tel->seq;

        p_buf[2] = (uint8_t)(((uint32_t)p_tel->veh_state & 0x1Fu)
                           | (((uint32_t)p_tel->line_state & 0x07u) << 5u));

        p_buf[3] = (uint8_t)(to_field((int32_t)p_tel->line_error,
                                      MSG_BITS_LINE_ERROR)
                           | ((p_tel->b_line_valid ? 1u : 0u) << 7u));

        p_buf[4] = (uint8_t)(((uint32_t)p_tel->speed_pct & 0x7Fu)
                           | ((p_tel->b_hump_sat ? 1u : 0u) << 7u));

        p_buf[5] = (uint8_t)((uint32_t)p_tel->hump_mm & 0x7Fu);

        p_buf[6] = (uint8_t)to_field((int32_t)p_tel->tilt_deg,
                                     MSG_BITS_TILT_DEG);

        p_buf[7] = p_tel->obst_distance_cm;

        fault_word = (uint16_t)((p_tel->fault_mask & 0x03FFu)
                              | (((uint16_t)p_tel->wifi_state & 0x07u) << 10u));
        p_buf[8]  = (uint8_t)(fault_word & 0xFFu);
        p_buf[9]  = (uint8_t)((fault_word >> 8u) & 0xFFu);

        p_buf[10] = (uint8_t)(p_tel->encoder_delta & 0xFFu);
        p_buf[11] = (uint8_t)((p_tel->encoder_delta >> 8u) & 0xFFu);

        written = MSG_LEN_TELEMETRY;
    }

    return (written);
}

bool msg_unpack_telemetry(const uint8_t *p_buf, uint8_t buf_len,
                          msg_telemetry_t *p_tel)
{
    uint16_t fault_word;
    bool     b_ok = false;

    if ((NULL != p_buf) && (NULL != p_tel)
        && (buf_len >= MSG_LEN_TELEMETRY)
        && (MSG_SCHEMA_VERSION == p_buf[0]))
    {
        p_tel->schema       = p_buf[0];
        p_tel->seq          = p_buf[1];
        p_tel->veh_state    = (uint8_t)(p_buf[2] & 0x1Fu);
        p_tel->line_state   = (uint8_t)((p_buf[2] >> 5u) & 0x07u);
        p_tel->line_error   = (int8_t)sign_extend((uint32_t)(p_buf[3] & 0x7Fu),
                                                  MSG_BITS_LINE_ERROR);
        p_tel->b_line_valid = (0u != (p_buf[3] & 0x80u));
        p_tel->speed_pct    = (uint8_t)(p_buf[4] & 0x7Fu);
        p_tel->b_hump_sat   = (0u != (p_buf[4] & 0x80u));
        p_tel->hump_mm      = (uint8_t)(p_buf[5] & 0x7Fu);
        p_tel->tilt_deg     = (int8_t)sign_extend((uint32_t)(p_buf[6] & 0x7Fu),
                                                  MSG_BITS_TILT_DEG);
        p_tel->obst_distance_cm = p_buf[7];

        fault_word          = (uint16_t)((uint16_t)p_buf[8]
                                       | ((uint16_t)p_buf[9] << 8u));
        p_tel->fault_mask   = (uint16_t)(fault_word & 0x03FFu);
        p_tel->wifi_state   = (uint8_t)((fault_word >> 10u) & 0x07u);

        p_tel->encoder_delta = (uint16_t)((uint16_t)p_buf[10]
                                        | ((uint16_t)p_buf[11] << 8u));
        b_ok = true;
    }

    return (b_ok);
}
