/*
 * subsystem2.h
 *
 * Subsystem 2 -- Motion Control.  Buddy 2 (Ze Kai), 2501273.
 *
 * Implements Statechart 2 of Design Review V2 section 6.2, which was
 * redrawn after the Week 6 review found the original "receives
 * instructions from the Pico / Interrupt Occurs" version unimplementable.
 *
 * This subsystem is the single motor writer.  No other module may touch
 * PWM slices 4 or 5.  It is also the task that satisfies FR11 and NFR10:
 * it waits on the E-STOP mask of the shared fault flag and brakes within
 * one 10 ms cycle of seeing a bit.
 *
 * PUBLIC INTERFACE: everything another subsystem may use.  Anything else
 * stays private in subsystem2.c.
 */

#ifndef SUBSYSTEM2_H
#define SUBSYSTEM2_H

#include "../app.h"
#include "../msg_defs.h"
#include <stdint.h>
#include <stdbool.h>

/* Statechart 2 states.  Encoded into 3 bits for telemetry. */
typedef enum
{
    M_INIT      = 0,
    M_IDLE      = 1,
    M_LINE_PID  = 2,
    M_MOVE      = 3,
    M_STALL     = 4,
    M_ENC_FAULT = 5,
    M_ESTOP     = 6
} s2_state_t;

/* ---------------------------------------------------------------------
 * Encoder geometry.  PROVISIONAL -- counts per revolution has never been
 * stated (risk R8) and the wheel diameter is nominal.  Both must be
 * measured before any distance or turn figure is trusted.
 * --------------------------------------------------------------------- */
#define S2_COUNTS_PER_REV       (20)    /* PROVISIONAL: measure this      */
#define S2_WHEEL_DIAM_MM        (65)    /* PROVISIONAL: measure this      */
#define S2_TRACK_WIDTH_MM       (140)   /* PROVISIONAL: wheel separation  */

/* PID gains, in 1/256 fixed point.  Integer maths only: the Cortex-M0+ has
   no FPU and Barr-C 5.4a asks that floating point be avoided where fixed
   point will do.  PROVISIONAL -- to be tuned on the bench (A3). */
#define S2_KP_Q8                (180)
#define S2_KI_Q8                (12)
#define S2_KD_Q8                (60)
#define S2_INTEGRAL_LIMIT       (4000)

/* Stall detection: drive commanded above this duty with no encoder edge
   for this long means the wheel is not turning. */
#define S2_STALL_DUTY_PCT       (25u)
#define S2_STALL_TIMEOUT_MS     (300u)

/* line_error older than this is treated as unusable (Statechart 2
   M_LINE_PID).  Line Sensor runs every 5 ms, so three missed updates. */
#define S2_LINE_STALE_MS        (20u)

/* Message buffer: Vehicle Controller -> Motion Control.  Owned here
   because this subsystem is the consumer. */
IMPORT ID mbf_motion_cmd;

/* Current state, for telemetry and for the Controller's own decisions. */
s2_state_t s2_get_state(void);

/* Latest measured wheel speeds, in encoder counts per second. */
void s2_get_speeds(int32_t *p_left, int32_t *p_right);

/* Total distance travelled since start, in millimetres.  Used by the IMU
   subsystem to accumulate hump height over distance rather than by
   double-integrating acceleration. */
int32_t s2_get_distance_mm(void);

/* Encoder delta since the previous telemetry frame, for FR9. */
uint16_t s2_take_encoder_delta(void);

/* Send a motion command.  Only the Vehicle Controller should call this. */
ER s2_send_command(const msg_motion_cmd_t *p_cmd);

/* Private to subsystem 2, shared between its own .c files. */
IMPORT ID   tid_motion;
IMPORT void motion_task(INT stacd, void *exinf);

#endif /* SUBSYSTEM2_H */
