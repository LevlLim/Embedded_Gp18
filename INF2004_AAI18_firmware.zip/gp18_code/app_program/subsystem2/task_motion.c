/*
 * task_motion.c
 *
 * Subsystem 2 -- the Motion Control task.  Statechart 2, Design Review V2
 * section 6.2.
 *
 * This is the highest-priority application task and the one FR11 depends
 * on.  Its 10 ms cycle is, in order:
 *   1. read the fault flag and brake immediately if any E-STOP bit is set
 *   2. read the encoders
 *   3. run the state machine
 *   4. apply the motor outputs
 *
 * Step 1 comes first deliberately: it means the worst case from a fault
 * bit being set to the brake being applied is one period plus the brake
 * itself, regardless of what state the machine is in.
 */

#include "subsystem2.h"
#include "motor_control.h"
#include "../fault.h"
#include "../drivers/gpio_irq.h"
#include "../drivers/rp2040_regs.h"
#include "../subsystem3/subsystem3.h"
#include "../subsystem5/subsystem5.h"

EXPORT ID tid_motion      = 0;
EXPORT ID mbf_motion_cmd  = 0;

/* ---------------------------------------------------------------------
 * Private state
 * --------------------------------------------------------------------- */

static volatile s2_state_t state = M_INIT;

static int32_t  speed_left_cps  = 0;    /* counts per second */
static int32_t  speed_right_cps = 0;
static int32_t  distance_mm     = 0;

static int32_t  prev_count_left  = 0;
static int32_t  prev_count_right = 0;
static uint32_t encoder_accum    = 0u;  /* for the telemetry delta */

/* Active move target, used by M_MOVE. */
static int32_t  target_left   = 0;
static int32_t  target_right  = 0;
static uint8_t  move_duty     = 0u;
static int8_t   move_dir_l    = 0;
static int8_t   move_dir_r    = 0;

static uint8_t  speed_setpoint_pct = PROV_CRUISE_PCT;
static uint8_t  last_cmd_seq       = 0xFFu;

/* ---------------------------------------------------------------------
 * Private functions
 * --------------------------------------------------------------------- */

/*
 * Update the measured wheel speeds and the odometer from the encoder
 * block.  Called once per cycle.
 */
static void update_odometry(const gpio_irq_encoders_t *p_enc)
{
    int32_t delta_left  = p_enc->count_left  - prev_count_left;
    int32_t delta_right = p_enc->count_right - prev_count_right;
    int32_t mean_delta;

    prev_count_left  = p_enc->count_left;
    prev_count_right = p_enc->count_right;

    /* counts per 10 ms -> counts per second */
    speed_left_cps  = (delta_left  * 1000) / PERIOD_MOTION_MS;
    speed_right_cps = (delta_right * 1000) / PERIOD_MOTION_MS;

    mean_delta   = (delta_left + delta_right) / 2;
    distance_mm += motor_counts_to_mm(mean_delta);

    /* Unsigned accumulation for the telemetry delta field. */
    encoder_accum += (uint32_t)((delta_left < 0) ? -delta_left : delta_left);
}

/*
 * Stall check.  Drive commanded above the threshold but no encoder edge
 * for longer than the timeout means a wheel is not turning.
 */
static bool is_stalled(const gpio_irq_encoders_t *p_enc, uint8_t duty_pct)
{
    uint32_t idle_us;
    bool     b_stalled = false;

    if (duty_pct >= S2_STALL_DUTY_PCT)
    {
        idle_us = RP2040_NOW_US() - p_enc->last_edge_us;

        if (idle_us > (S2_STALL_TIMEOUT_MS * 1000u))
        {
            b_stalled = true;
        }
    }

    return (b_stalled);
}

/*
 * Accept a new command if one is waiting.  Returns true if the state
 * machine should act on it.  Duplicate sequence numbers are ignored, so a
 * retransmitted command cannot execute twice.
 */
static bool take_command(msg_motion_cmd_t *p_cmd)
{
    uint8_t buf[MSG_LEN_MOTION_CMD];
    INT     received;
    bool    b_new = false;

    received = tk_rcv_mbf(mbf_motion_cmd, buf, TMO_POL);

    if (received >= (INT)MSG_LEN_MOTION_CMD)
    {
        if (msg_unpack_motion_cmd(buf, MSG_LEN_MOTION_CMD, p_cmd))
        {
            if (p_cmd->seq != last_cmd_seq)
            {
                last_cmd_seq = p_cmd->seq;
                b_new        = true;
            }
        }
    }

    return (b_new);
}

/*
 * Set up an encoder-measured move.  Distance moves drive both wheels the
 * same way; turns drive them opposite.
 */
static void begin_move(const msg_motion_cmd_t *p_cmd,
                       const gpio_irq_encoders_t *p_enc)
{
    int32_t counts;

    switch (p_cmd->type)
    {
        case MSG_CMD_FORWARD:
            counts     = motor_mm_to_counts((int32_t)p_cmd->arg);
            move_dir_l = 1;
            move_dir_r = 1;
            break;

        case MSG_CMD_TURN_L:
            counts     = motor_degrees_to_counts((int32_t)p_cmd->arg);
            move_dir_l = -1;
            move_dir_r = 1;
            break;

        case MSG_CMD_TURN_R:
            counts     = motor_degrees_to_counts((int32_t)p_cmd->arg);
            move_dir_l = 1;
            move_dir_r = -1;
            break;

        case MSG_CMD_U_TURN:
            counts     = motor_degrees_to_counts(180);
            move_dir_l = 1;
            move_dir_r = -1;
            break;

        default:
            counts     = 0;
            move_dir_l = 0;
            move_dir_r = 0;
            break;
    }

    target_left  = p_enc->count_left  + (move_dir_l * counts);
    target_right = p_enc->count_right + (move_dir_r * counts);
    move_duty    = speed_setpoint_pct;

    motor_pid_reset();
}

/*
 * True when both wheels have reached their encoder targets.
 */
static bool move_complete(const gpio_irq_encoders_t *p_enc)
{
    bool b_left_done;
    bool b_right_done;

    if (move_dir_l >= 0)
    {
        b_left_done = (p_enc->count_left >= target_left);
    }
    else
    {
        b_left_done = (p_enc->count_left <= target_left);
    }

    if (move_dir_r >= 0)
    {
        b_right_done = (p_enc->count_right >= target_right);
    }
    else
    {
        b_right_done = (p_enc->count_right <= target_right);
    }

    return (b_left_done && b_right_done);
}

/*
 * Line-following step.  Reads the timestamped line error and refuses to
 * steer on a stale value -- it decelerates instead, which is the
 * behaviour Statechart 2 specifies.
 */
static void step_line_pid(void)
{
    s3_line_reading_t reading;
    int32_t           correction;
    int32_t           base;
    int32_t           duty_l;
    int32_t           duty_r;

    if (!s3_read_line(&reading) || !reading.b_valid
        || ((app_now_ms() - reading.timestamp_ms) > S2_LINE_STALE_MS))
    {
        /*
         * Stale or invalid line error.  Acting on an old steering value is
         * worse than not steering: it commits the car to a turn that may
         * no longer apply.  Hold straight and slow down.
         */
        motor_set(1, (uint8_t)(speed_setpoint_pct / 2u),
                  1, (uint8_t)(speed_setpoint_pct / 2u));
        return;
    }

    /* Steering correction from the line error; setpoint is zero error. */
    correction = motor_pid_step(0, (int32_t)reading.error, true);

    base   = (int32_t)speed_setpoint_pct;
    duty_l = base - correction;
    duty_r = base + correction;

    if (duty_l < 0)   { duty_l = 0; }
    if (duty_r < 0)   { duty_r = 0; }
    if (duty_l > 100) { duty_l = 100; }
    if (duty_r > 100) { duty_r = 100; }

    motor_set(1, (uint8_t)duty_l, 1, (uint8_t)duty_r);
}

/* ---------------------------------------------------------------------
 * The task
 * --------------------------------------------------------------------- */

EXPORT void motion_task(INT stacd, void *exinf)
{
    gpio_irq_encoders_t enc;
    msg_motion_cmd_t    cmd;
    uint16_t            fault_bits;

    (void)stacd;
    (void)exinf;

    state = M_IDLE;

    for (;;)
    {
        /* ---- 1. e-stop first, before anything else ---- */
        fault_bits = fault_get();

        if (0u != (fault_bits & FAULT_MASK_ESTOP))
        {
            if (M_ESTOP != state)
            {
                motor_brake();
                state = M_ESTOP;
            }

            /* Latched: stay braked until the Controller clears the bit.
               A bouncing source therefore cannot release the brake. */
            (void)tk_dly_tsk(PERIOD_MOTION_MS);
            continue;
        }

        if (M_ESTOP == state)
        {
            /* The Controller cleared the fault: return to idle, not
               straight back to driving.  Resuming a move across an e-stop
               would be surprising and unsafe. */
            motor_pid_reset();
            state = M_IDLE;
        }

        /* A DEGRADE fault caps the speed but does not stop the car. */
        if (0u != (fault_bits & FAULT_MASK_DEGRADE))
        {
            if (speed_setpoint_pct > PROV_DEGRADE_PCT)
            {
                speed_setpoint_pct = PROV_DEGRADE_PCT;
            }
        }

        /* ---- 2. encoders ---- */
        gpio_irq_read_encoders(&enc);
        update_odometry(&enc);

        /* ---- 3. commands ---- */
        if (take_command(&cmd))
        {
            switch (cmd.type)
            {
                case MSG_CMD_STOP:
                    motor_brake();
                    state = M_IDLE;
                    break;

                case MSG_CMD_LINE_PID:
                    motor_pid_reset();
                    state = M_LINE_PID;
                    break;

                default:
                    begin_move(&cmd, &enc);
                    state = M_MOVE;
                    break;
            }
        }

        /* ---- 4. state machine ---- */
        switch (state)
        {
            case M_IDLE:
                motor_brake();
                break;

            case M_LINE_PID:
                step_line_pid();
                if (is_stalled(&enc, speed_setpoint_pct))
                {
                    motor_brake();
                    fault_set(FAULT_MOTOR_STALL);
                    state = M_STALL;
                }
                break;

            case M_MOVE:
                if (move_complete(&enc))
                {
                    motor_brake();
                    state = M_IDLE;
                    /* MOVE_DONE tells the Controller the manoeuvre ended. */
                    s5_post_event(S5_EVT_MOVE_DONE);
                }
                else
                {
                    motor_set(move_dir_l, move_duty, move_dir_r, move_duty);

                    if (is_stalled(&enc, move_duty))
                    {
                        motor_brake();
                        fault_set(FAULT_MOTOR_STALL);
                        state = M_STALL;
                    }
                }
                break;

            case M_STALL:
            case M_ENC_FAULT:
                motor_brake();
                break;

            default:
                motor_brake();
                state = M_IDLE;
                break;
        }

        (void)tk_dly_tsk(PERIOD_MOTION_MS);
    }
}

/* ---------------------------------------------------------------------
 * Public accessors
 * --------------------------------------------------------------------- */

EXPORT s2_state_t s2_get_state(void)
{
    return (state);
}

EXPORT void s2_get_speeds(int32_t *p_left, int32_t *p_right)
{
    if (NULL != p_left)
    {
        *p_left = speed_left_cps;
    }
    if (NULL != p_right)
    {
        *p_right = speed_right_cps;
    }
}

EXPORT int32_t s2_get_distance_mm(void)
{
    return (distance_mm);
}

EXPORT uint16_t s2_take_encoder_delta(void)
{
    uint32_t value = encoder_accum;

    encoder_accum = 0u;

    return ((uint16_t)(value & 0xFFFFu));
}

EXPORT ER s2_send_command(const msg_motion_cmd_t *p_cmd)
{
    uint8_t buf[MSG_LEN_MOTION_CMD];
    uint8_t len;

    if (NULL == p_cmd)
    {
        return (E_PAR);
    }

    len = msg_pack_motion_cmd(p_cmd, buf, sizeof(buf));
    if (0u == len)
    {
        return (E_PAR);
    }

    /* TMO_POL: the Controller must never block behind Motion Control. */
    return (tk_snd_mbf(mbf_motion_cmd, buf, (INT)len, TMO_POL));
}
