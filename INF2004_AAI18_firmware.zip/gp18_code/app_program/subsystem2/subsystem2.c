/*
 * subsystem2.c
 *
 * Subsystem 2 -- Motion Control: creates its kernel objects and starts
 * its task.
 *
 * APIs used: tk_cre_mbf, app_start_task
 */

#include "subsystem2.h"
#include "motor_control.h"
#include "../drivers/gpio_irq.h"

/* Four pending commands is enough: the Controller is the only sender and
   it issues one manoeuvre at a time.  A deeper buffer would only hide a
   Controller that is falling behind. */
#define S2_CMD_QUEUE_DEPTH  (4)

EXPORT ER subsystem2_init(void)
{
    T_CMBF cmbf = {0};
    ER     er;

    er = motor_init();
    if (er < E_OK)
    {
        return (er);
    }

    /* The IO_BANK0 dispatcher is shared with subsystem 5 (ECHO), but it is
       created here because Motion Control is the higher-priority user and
       must exist before any wheel turns. */
    er = gpio_irq_init();
    if (er < E_OK)
    {
        return (er);
    }

    cmbf.mbfatr  = TA_TFIFO;
    cmbf.bufsz   = (INT)(MSG_LEN_MOTION_CMD * S2_CMD_QUEUE_DEPTH);
    cmbf.maxmsz  = (INT)MSG_LEN_MOTION_CMD;

    mbf_motion_cmd = tk_cre_mbf(&cmbf);

    return ((mbf_motion_cmd < E_OK) ? (ER)mbf_motion_cmd : E_OK);
}

EXPORT ER subsystem2_start(void)
{
    /*
     * Pinned to core 0 (TP_PRC1).  Motion Control and the sensing tasks it
     * reads from share a core so that their data never crosses the
     * inter-core boundary, and Telemetry's network work is left free to
     * run on the other core without ever delaying this task.
     */
    tid_motion = app_start_task(motion_task, PRI_MOTION_CONTROL,
                                TP_PRC1, "motion_task");

    return ((tid_motion < E_OK) ? (ER)tid_motion : E_OK);
}
