# INF2004 Group AAI18 — Autonomous Robot Car Firmware

Firmware for the Week 10 / Week 13 build, written against
[INF2004_ProjectTemplate](https://github.com/sirfonzie/INF2004_ProjectTemplate)
(micro T-Kernel 3.0 on the Raspberry Pi Pico W) and implementing
**Design Review V2**, including **Change Requirement 1 (minimum-bit data
representation)**.

> **Read this first.** None of this code has been compiled with the ARM
> toolchain or run on hardware. See [Status](#status-what-is-and-is-not-verified).

---

## Status: what is and is not verified

| | |
|---|---|
| ✅ **Host unit tests pass** | 39/39 checks, including 49 152 exhaustive motion-command round trips. Zero warnings under `-Wall -Wextra -Wconversion -Wsign-conversion`. |
| ✅ **All 20 sources parse clean** | `gcc -fsyntax-only` against stub kernel headers, in both `TEST=0` and `TEST=1` configurations. |
| ❌ **Never cross-compiled** | No `arm-none-eabi-gcc` and no Pico SDK were available where this was written. Expect to fix real compile errors on first build. |
| ❌ **Never run on hardware** | Every register offset, every timing constant and every threshold is from a datasheet or an estimate, not from silicon. |
| ❌ **No measurement anywhere** | Everything marked `PROVISIONAL` is a guess that unblocks implementation. |

**First bench session should be, in this order:** build → fix compile
errors → `make TEST=1` → read the self-test output → confirm the ADC is
converting and the IMU answers on I²C → *then* let a wheel turn.

---

## Layout

```
app_program/
  app.h                  pin map, priorities, periods, PROVISIONAL constants
  app_main.c             usermain(), task creation, init ordering
  msg_defs.h/.c          ★ CR1: every packed field, encode/decode  (Buddy 1)
  fault.h/.c             ★ CR1: the 10-bit shared fault bitmask    (Buddy 5)
  drivers/
    rp2040_regs.h        registers the template's BSP does not provide
    adc_sampler.h/.c     sole owner of the ADC + mux               (Buddy 3)
    gpio_irq.h/.c        single IO_BANK0 dispatcher             (Buddy 2 + 5)
    i2c0.h/.c            polled I²C0 master for the IMU            (Buddy 4)
  subsystem1/            Telemetry / Comms — WiFi, MQTT, remote cmds
  subsystem2/            Motion Control — motors, encoders, PID, e-stop
  subsystem3/            Line + Barcode — ADC consumers, decode
  subsystem4/            IMU / Terrain — hump, tilt, collision
  subsystem5/            Obstacle + Vehicle Controller — mission state
testing/
  host/                  runs on a PC: CR1 round-trip evidence
  stub/                  fake kernel headers, syntax checking only
```

### Installing into the template

Copy `app_program/` over the template's `app_program/`, replacing the
example subsystems. The template's `build_make/mtkernel_3/app_program/subdir.mk`
globs `../app_program/*.c` and `../app_program/*/*.c`, so the subsystem
folders are picked up automatically — **but `drivers/` is also one level
down, so it is picked up too.** No makefile change is needed.

```sh
cd build_make
make                      # normal build
make TEST=1               # with on-target self-tests
make MQTT=1 NET=lwip      # with real MQTT instead of console telemetry
```

Telemetry prints hex frames to the USB console unless built with
`MQTT=1`, so bring-up needs no broker.

---

## What the BSP did not provide

The template's BSP (`include/bsp/.../libbsp.h`) exposes **GPIO and PWM
only**, and the application include path (`-I../include -I../config
-I../kernel/knlinc`) does not reach the Pico SDK hardware headers. So
`hardware/adc.h`, `hardware/i2c.h` and `hardware/gpio.h` are *not*
available to our code.

Three peripherals the design needs are therefore written against the
registers directly, in the same style as the template's own
`libbsp_pwm.c`:

| Driver | Why | Risk |
|---|---|---|
| `adc_sampler` | One ADC behind a shared mux; two claimants corrupt each other | Offsets from the datasheet, unverified |
| `gpio_irq` | All GPIO edges arrive on **one** IO_BANK0 vector — no per-pin IRQ | Dispatcher cost at top speed unknown (risk R8) |
| `i2c0` | IMU on I²C0 | `FS_SCL_HCNT`/`LCNT` computed for 125 MHz; verify the bit rate on a scope |

`set_w()`/`clr_w()` in the template map to the RP2040's **atomic**
set/clear aliases (`base+0x2000` / `base+0x3000`), so bit manipulation
through them is genuinely atomic in hardware — worth knowing, as it
strengthens the CR1 race-condition argument.

---

## Change Requirement 1: where it actually lives

| CR1 requirement | Where |
|---|---|
| Minimum bits per field | `msg_defs.h` — 22 fields with range, width, encoding, owner |
| Fault conditions in a shared bitmask | `fault.h` — 10 bits, severity masks, set/clear discipline |
| Compact binary MQTT | `msg_pack_telemetry()` — 12 bytes vs ~120 as text |
| Race-free packed access | `fault_set()` never read-modify-writes; `tk_set_flg` ORs bits in |
| Data representation table | `msg_defs.h` + Design Review V2 §7.1 |
| Message size comparison | `testing/host` prints it — see below |
| RAM comparison | **Not done.** Needs the linker map of a tagged baseline build |
| Correctness evidence | `testing/host` — 39 checks incl. exhaustive round trip |

```
--- Change Requirement 1: message size comparison ---
  message                  before    after    saving
  motion command                8        2       75%
  barcode command               4        1       75%
  obstacle profile             16        5       68%
  telemetry frame (vs text)   120       12       90%
```

### ⚠ The baseline build is still owed, and it expires

CR1 deliverables 2, 3 and 4 need **before and after** figures. The "after"
side is this code. The "before" side does not exist yet, and **cannot be
reconstructed once packing is committed**. Tag a baseline build and record
its `arm-none-eabi-size` / `.map` RAM figures *before* merging this.
(Design Review V2 §7.5, risk R7.)

### Fields deliberately NOT packed

Recorded so the exclusion reads as judgement rather than oversight
(§7.4): encoder counters, ECHO timestamps and the `line_error` timestamp
stay native 32-bit. A free-running counter's valid range genuinely *is*
32 bits, so a 32-bit word already satisfies NFR12 — packing them would
buy a few bytes and pay with torn reads and wrapped staleness checks in
the 1 ms and 10 ms paths.

---

## Barr-C:2018 compliance

Automated checks, all passing:

| Rule | Check | Result |
|---|---|---|
| 3.5a | No tab characters | **0** |
| 3.6a | LF line endings only | **0 CRLF** |
| 1.2 | Lines ≤ 80 columns | **0 over** |
| 5.2b | No `short` / `long` keywords | **0** (comment prose only) |
| 5.2a | Fixed-width types for app data | `uint8_t`…`int32_t` throughout |
| 4.2b | Header guards | every header |
| 4.3c | Each `.c` includes its own `.h` | yes |
| 6.2e | Private functions `static` | yes |
| 5.6a | Booleans are `bool` | yes |
| 1.3 | Braces on every block | yes |

### Declared deviations

Barr-C has a formal deviation procedure; these are ours, declared rather
than hidden.

**D1 — 6.2a (functions ≤ 100 lines): five functions exceed it.**

| Function | Lines |
|---|---|
| `step_phase_machine()` (obstacle) | 171 |
| `controller_task()` | 151 |
| `step_hump_machine()` (IMU) | 147 |
| `motion_task()` | 126 |
| `i2c0_write_read()` | 123 |

All but the last are a single `switch` over a statechart state. Splitting
them further was tried and **moved the problem into the helper rather
than solving it** — the state machine is genuinely that wide. Breaking one
switch across several functions would hide the state transitions, which
are the thing a reviewer most needs to see in one place. `i2c0_write_read()`
is one hardware transaction whose phases share a deadline and an error
path; splitting it would duplicate the recovery logic.

*If the module owner disagrees, the cleanest fix is one function per
state, not one per group of states.*

**D2 — 5.1a (`_t` suffix) not applied to kernel types.** `ER`, `ID`,
`UINT` etc. come from micro T-Kernel and cannot be renamed. Our own types
all use `_t`.

**D3 — 1.1 `//` comments.** Barr-C permits C99 comments; the template uses
both styles. We use `/* */` in new code.

**D4 — Template style conflict.** The template's own sources use tabs and
`Inline`. Our files follow Barr-C (spaces); we did not reformat the
template.

---

## Known weak points (be ready to be asked)

These are in the code because the design has them, not because they were
overlooked. Each maps to an open assumption or risk in Design Review V2.

1. **Barcode decoding is the most likely thing to fail** (risk R5). It
   depends on 1 ms sampling resolving the narrowest bar, with A1 and A2
   both unvalidated. `s3_decode_widths()` uses a deliberately simple
   4-bar scheme that **must be replaced** once the real track's symbols
   are measured.
2. **Hump height from accelerometer-only tilt** (A7). No gyroscope, so
   `compute_pitch_deg()` is corrupted by linear acceleration. FR5's
   ±5 mm is ambitious and the tolerance should be re-derived from the
   worst measured error.
3. **D_detect and D_stop are guesses** (`PROV_D_DETECT_CM`,
   `PROV_D_STOP_CM`). Every packed distance width depends on them, so
   measuring them also re-opens §7.1.
4. **Servo may face away when an obstacle appears** (risk R6). Mitigated
   by bounding the sweep arc; not eliminated.
5. **Encoder ISR cost unknown** (risk R8). `gpio_irq_max_duration_us()`
   exists to answer it — read it during the first timing run.
6. **Quadrature decoding counts one channel only.** Full 4× decoding
   would need both channels' edges; this counts A edges and reads B for
   direction, which halves resolution and mis-counts on direction
   reversal at very low speed.
7. **`S2_COUNTS_PER_REV = 20` is a placeholder.** Every distance and turn
   figure scales off it. Measure it first — it is one wheel rotation
   counted by hand.

---

## Test plan coverage

| Test | What | Where | Status |
|---|---|---|---|
| T2 | Packed field min/max/out-of-range | `testing/host` | ✅ automated |
| T4 | Fault bitmask, 100-iteration injection | `subsystem5_test.c` | on target |
| T5 | **E-stop latency** | `subsystem2_test.c` | ⚠ software path only — the logic-analyser capture is still owed |
| T6 | CPU and deadlines | — | ⚠ not implemented |
| T7 | Shared ADC integrity | `subsystem3_test.c` | on target |
| T8 | Stale line error | — | ⚠ not implemented |

T5's full evidence needs a GPIO toggled at the fault source and another
when both motor pins go LOW, captured on a logic analyser. The software
timer in `subsystem2_test.c` measures only Motion Control's reaction, not
the hardware path, and **should not be presented as FR11 evidence.**

---

## Ownership

Only the owner edits a subsystem folder. `app.h`, `app_main.c`,
`msg_defs.*` and `fault.*` are shared — change them by agreement, because
every subsystem decodes what another encodes.

| # | Buddy | Owns |
|---|---|---|
| 1 | Levl Lim (2501118) | `subsystem1/`, **`msg_defs.*`** |
| 2 | Ze Kai (2501273) | `subsystem2/`, `drivers/gpio_irq.*` (shared) |
| 3 | Zhi Kai (2500466) | `subsystem3/`, `drivers/adc_sampler.*` |
| 4 | Jian Yan (2500853) | `subsystem4/`, `drivers/i2c0.*` |
| 5 | Jun Hong (2501666) | `subsystem5/`, **`fault.*`** |
