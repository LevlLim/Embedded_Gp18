/*
 * test_host.c
 *
 * Group AAI18 -- host-side unit tests for the pure logic.
 *
 * WHY THIS EXISTS
 * ---------------
 * Change Requirement 1 asks for evidence that "the revised representation
 * causes no loss of required functionality".  The round-trip proof for
 * that does not need the robot: the encode and decode functions are pure,
 * so they can be exercised exhaustively on a PC, far faster and far more
 * thoroughly than on the target.
 *
 * This harness also serves as the min / max / out-of-range test called
 * for in test T2 of the design review, and its output is the artefact to
 * attach as evidence.
 *
 * BUILD AND RUN
 *     cd testing/host && make && ./test_host
 *
 * It compiles with the HOST compiler, not the ARM one, and links only the
 * pure modules -- nothing here touches the kernel or the hardware.
 */

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

#include "../../app_program/msg_defs.h"

static int tests_run    = 0;
static int tests_passed = 0;

#define CHECK_TRUE(cond, label)                                         \
    do {                                                                \
        tests_run++;                                                    \
        if (cond) {                                                     \
            tests_passed++;                                             \
        } else {                                                        \
            printf("  FAIL: %s  (%s:%d)\n", (label), __FILE__, __LINE__); \
        }                                                               \
    } while (0)

#define CHECK_EQ_INT(got, want, label)                                  \
    do {                                                                \
        tests_run++;                                                    \
        if ((long)(got) == (long)(want)) {                              \
            tests_passed++;                                             \
        } else {                                                        \
            printf("  FAIL: %s  got %ld want %ld  (%s:%d)\n",           \
                   (label), (long)(got), (long)(want),                  \
                   __FILE__, __LINE__);                                 \
        }                                                               \
    } while (0)

/* ---------------------------------------------------------------------
 * Motion command: every command type, every argument, every sequence.
 * This is exhaustive -- 6 x 1024 x 8 combinations -- which is the kind of
 * coverage only a host test can give.
 * --------------------------------------------------------------------- */
static void test_motion_cmd_exhaustive(void)
{
    msg_motion_cmd_t in;
    msg_motion_cmd_t out;
    uint8_t          buf[MSG_LEN_MOTION_CMD];
    int              failures = 0;
    unsigned         type;
    unsigned         arg;
    unsigned         seq;

    printf("motion command: exhaustive round trip\n");

    for (type = 0u; type <= 5u; type++)
    {
        for (arg = 0u; arg <= MSG_MAX_CMD_ARG; arg++)
        {
            for (seq = 0u; seq <= 7u; seq++)
            {
                in.type = (msg_cmd_type_t)type;
                in.arg  = (uint16_t)arg;
                in.seq  = (uint8_t)seq;

                memset(buf, 0, sizeof(buf));

                if (MSG_LEN_MOTION_CMD != msg_pack_motion_cmd(&in, buf,
                                                              sizeof(buf)))
                {
                    failures++;
                    continue;
                }
                if (!msg_unpack_motion_cmd(buf, sizeof(buf), &out))
                {
                    failures++;
                    continue;
                }

                if ((out.type != in.type) || (out.arg != in.arg)
                    || (out.seq != in.seq))
                {
                    failures++;
                }
            }
        }
    }

    CHECK_EQ_INT(failures, 0, "motion cmd exhaustive round trip");
    printf("  %u combinations checked, %d bytes per message\n",
           6u * (MSG_MAX_CMD_ARG + 1u) * 8u, MSG_LEN_MOTION_CMD);
}

/* ---------------------------------------------------------------------
 * Saturation: an out-of-range argument must CLAMP, never wrap.
 *
 * This is the test that matters most for safety.  A wrapped distance or
 * width produces a confident, wrong bypass decision, which is worse than
 * an obviously clipped one.
 * --------------------------------------------------------------------- */
static void test_saturation(void)
{
    msg_motion_cmd_t in;
    msg_motion_cmd_t out;
    uint8_t          buf[MSG_LEN_MOTION_CMD];
    bool             b_sat;

    printf("saturation: out-of-range must clamp, never wrap\n");

    /* 2000 mm exceeds the 10-bit field.  It must come back as 1023,
       NOT as 2000 mod 1024 = 976. */
    in.type = MSG_CMD_FORWARD;
    in.arg  = 2000u;
    in.seq  = 1u;

    (void)msg_pack_motion_cmd(&in, buf, sizeof(buf));
    (void)msg_unpack_motion_cmd(buf, sizeof(buf), &out);

    CHECK_EQ_INT(out.arg, MSG_MAX_CMD_ARG, "arg 2000 clamps to 1023");
    CHECK_TRUE(out.arg != (2000u % 1024u), "arg 2000 did NOT wrap to 976");

    /* Saturating helpers report that clamping occurred. */
    b_sat = false;
    CHECK_EQ_INT(msg_sat_u16(300u, 255u, &b_sat), 255, "sat_u16 clamps");
    CHECK_TRUE(b_sat, "sat_u16 reports saturation");

    b_sat = false;
    CHECK_EQ_INT(msg_sat_u16(100u, 255u, &b_sat), 100, "sat_u16 passes");
    CHECK_TRUE(!b_sat, "sat_u16 reports no saturation");

    b_sat = false;
    CHECK_EQ_INT(msg_sat_i8(-200, 63, &b_sat), -63, "sat_i8 clamps negative");
    CHECK_TRUE(b_sat, "sat_i8 reports saturation");
}

/* ---------------------------------------------------------------------
 * Signed fields must survive the round trip with their sign.
 * --------------------------------------------------------------------- */
static void test_signed_fields(void)
{
    msg_obstacle_t in;
    msg_obstacle_t out;
    uint8_t        buf[MSG_LEN_OBSTACLE];
    int            bearing;
    int            failures = 0;

    printf("signed fields: sign extension across the full range\n");

    for (bearing = -63; bearing <= 63; bearing++)
    {
        memset(&in, 0, sizeof(in));
        in.distance_cm    = 100u;
        in.width_cm       = 20u;
        in.bearing_deg    = (int8_t)bearing;
        in.clear_left_cm  = 10u;
        in.clear_right_cm = 25u;
        in.side           = MSG_SIDE_LEFT;
        in.b_saturated    = false;

        memset(buf, 0, sizeof(buf));
        (void)msg_pack_obstacle(&in, buf, sizeof(buf));

        if (!msg_unpack_obstacle(buf, sizeof(buf), &out))
        {
            failures++;
            continue;
        }

        if (out.bearing_deg != in.bearing_deg)
        {
            failures++;
        }
    }

    CHECK_EQ_INT(failures, 0, "bearing -63..+63 round trips with sign");
}

/* ---------------------------------------------------------------------
 * Obstacle profile: boundary values on every field at once.
 * --------------------------------------------------------------------- */
static void test_obstacle_boundaries(void)
{
    msg_obstacle_t in;
    msg_obstacle_t out;
    uint8_t        buf[MSG_LEN_OBSTACLE];

    printf("obstacle profile: boundary values\n");

    in.distance_cm    = (uint8_t)MSG_MAX_OBST_DIST;
    in.width_cm       = (uint8_t)MSG_MAX_OBST_WIDTH;
    in.bearing_deg    = -63;
    in.clear_left_cm  = (uint8_t)MSG_MAX_OBST_CLEAR;
    in.clear_right_cm = 0u;
    in.side           = MSG_SIDE_RIGHT;
    in.b_saturated    = true;

    (void)msg_pack_obstacle(&in, buf, sizeof(buf));
    CHECK_TRUE(msg_unpack_obstacle(buf, sizeof(buf), &out), "unpack ok");

    CHECK_EQ_INT(out.distance_cm,    in.distance_cm,    "distance max");
    CHECK_EQ_INT(out.width_cm,       in.width_cm,       "width max");
    CHECK_EQ_INT(out.bearing_deg,    in.bearing_deg,    "bearing min");
    CHECK_EQ_INT(out.clear_left_cm,  in.clear_left_cm,  "clear left max");
    CHECK_EQ_INT(out.clear_right_cm, in.clear_right_cm, "clear right zero");
    CHECK_EQ_INT(out.side,           in.side,           "side");
    CHECK_TRUE(out.b_saturated == in.b_saturated,       "saturated flag");
}

/* ---------------------------------------------------------------------
 * Telemetry frame: round trip, and the schema guard.
 * --------------------------------------------------------------------- */
static void test_telemetry(void)
{
    msg_telemetry_t in;
    msg_telemetry_t out;
    uint8_t         buf[MSG_LEN_TELEMETRY];

    printf("telemetry frame: round trip and schema guard\n");

    memset(&in, 0, sizeof(in));
    in.seq              = 42u;
    in.veh_state        = msg_encode_veh_state(2u, 3u);
    in.line_state       = (uint8_t)MSG_LINE_TRACK;
    in.line_error       = -45;
    in.b_line_valid     = true;
    in.speed_pct        = 55u;
    in.hump_mm          = 120u;
    in.b_hump_sat       = true;
    in.tilt_deg         = -12;
    in.obst_distance_cm = 200u;
    in.fault_mask       = 0x0285u;      /* several faults at once */
    in.wifi_state       = 3u;
    in.encoder_delta    = 40000u;

    CHECK_EQ_INT(msg_pack_telemetry(&in, buf, sizeof(buf)),
                 MSG_LEN_TELEMETRY, "pack length");
    CHECK_TRUE(msg_unpack_telemetry(buf, sizeof(buf), &out), "unpack ok");

    CHECK_EQ_INT(out.seq,              in.seq,              "seq");
    CHECK_EQ_INT(out.veh_state,        in.veh_state,        "veh_state");
    CHECK_EQ_INT(out.line_state,       in.line_state,       "line_state");
    CHECK_EQ_INT(out.line_error,       in.line_error,       "line_error");
    CHECK_TRUE(out.b_line_valid    ==  in.b_line_valid,     "line_valid");
    CHECK_EQ_INT(out.speed_pct,        in.speed_pct,        "speed");
    CHECK_EQ_INT(out.hump_mm,          in.hump_mm,          "hump_mm");
    CHECK_TRUE(out.b_hump_sat      ==  in.b_hump_sat,       "hump_sat");
    CHECK_EQ_INT(out.tilt_deg,         in.tilt_deg,         "tilt");
    CHECK_EQ_INT(out.obst_distance_cm, in.obst_distance_cm, "obst distance");
    CHECK_EQ_INT(out.fault_mask,       in.fault_mask,       "fault mask");
    CHECK_EQ_INT(out.wifi_state,       in.wifi_state,       "wifi state");
    CHECK_EQ_INT(out.encoder_delta,    in.encoder_delta,    "encoder delta");

    /* A frame carrying the wrong schema version must be REJECTED, not
       decoded with shifted fields. */
    buf[0] = (uint8_t)(MSG_SCHEMA_VERSION + 1u);
    CHECK_TRUE(!msg_unpack_telemetry(buf, sizeof(buf), &out),
               "wrong schema version rejected");
}

/* ---------------------------------------------------------------------
 * Vehicle state: 3-bit parent + 2-bit substate must survive, because the
 * composite RUNNING state does not fit in 3 bits if flattened.
 * --------------------------------------------------------------------- */
static void test_veh_state(void)
{
    unsigned parent;
    unsigned sub;
    uint8_t  encoded;
    uint8_t  got_parent;
    uint8_t  got_sub;
    int      failures = 0;

    printf("vehicle state: parent + substate encoding\n");

    for (parent = 0u; parent <= 7u; parent++)
    {
        for (sub = 0u; sub <= 3u; sub++)
        {
            encoded = msg_encode_veh_state((uint8_t)parent, (uint8_t)sub);
            msg_decode_veh_state(encoded, &got_parent, &got_sub);

            if ((got_parent != parent) || (got_sub != sub))
            {
                failures++;
            }
            if (encoded > 31u)
            {
                failures++;   /* must fit in 5 bits */
            }
        }
    }

    CHECK_EQ_INT(failures, 0, "all 32 state combinations round trip in 5 bits");
}

/* ---------------------------------------------------------------------
 * Short buffers must be refused, not overrun.
 * --------------------------------------------------------------------- */
static void test_buffer_guards(void)
{
    msg_motion_cmd_t cmd = { MSG_CMD_FORWARD, 100u, 1u };
    msg_obstacle_t   obs;
    uint8_t          small[1];

    printf("buffer guards: short buffers refused\n");

    CHECK_EQ_INT(msg_pack_motion_cmd(&cmd, small, 1u), 0,
                 "pack refuses 1-byte buffer");
    CHECK_TRUE(!msg_unpack_motion_cmd(small, 1u, &cmd),
               "unpack refuses 1-byte buffer");
    CHECK_TRUE(!msg_unpack_obstacle(small, 1u, &obs),
               "obstacle unpack refuses short buffer");
    CHECK_EQ_INT(msg_pack_motion_cmd(NULL, small, sizeof(small)), 0,
                 "pack refuses NULL input");
}

/* ---------------------------------------------------------------------
 * The CR1 size comparison, printed as evidence.
 * --------------------------------------------------------------------- */
static void report_sizes(void)
{
    printf("\n--- Change Requirement 1: message size comparison ---\n");
    printf("  %-22s %8s %8s %9s\n", "message", "before", "after", "saving");
    printf("  %-22s %8d %8d %8d%%\n", "motion command",
           8, MSG_LEN_MOTION_CMD, (100 * (8 - MSG_LEN_MOTION_CMD)) / 8);
    printf("  %-22s %8d %8d %8d%%\n", "barcode command",
           4, MSG_LEN_BARCODE, (100 * (4 - MSG_LEN_BARCODE)) / 4);
    printf("  %-22s %8d %8d %8d%%\n", "obstacle profile",
           16, MSG_LEN_OBSTACLE, (100 * (16 - MSG_LEN_OBSTACLE)) / 16);
    printf("  %-22s %8d %8d %8d%%\n", "telemetry frame (vs text)",
           120, MSG_LEN_TELEMETRY, (100 * (120 - MSG_LEN_TELEMETRY)) / 120);
    printf("\n  'before' figures are the unpacked struct sizes recorded\n");
    printf("  against the baseline build; the telemetry comparison is\n");
    printf("  against the equivalent JSON text payload.\n");
    printf("  NOTE: these are the MESSAGE sizes only.  The RAM comparison\n");
    printf("  required by CR1 deliverable 2 must still come from the\n");
    printf("  linker map of the tagged baseline build.\n");
}

int main(void)
{
    printf("=== Group AAI18 host tests: minimum-bit representation ===\n\n");

    test_motion_cmd_exhaustive();
    test_saturation();
    test_signed_fields();
    test_obstacle_boundaries();
    test_telemetry();
    test_veh_state();
    test_buffer_guards();

    report_sizes();

    printf("\n=== %d/%d checks passed ===\n", tests_passed, tests_run);

    return ((tests_passed == tests_run) ? 0 : 1);
}
